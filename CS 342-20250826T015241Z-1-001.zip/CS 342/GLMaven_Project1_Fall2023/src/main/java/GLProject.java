/**************************
 *
 *  Project 1: Data Structure Library
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

//I was unable to finish the MyHashMap class and the HMIterator class.
public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to project 1");
		
	}
}
