import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyMoneyTest {
	
	public static MyMoney myMoneyTest1;
	public static MyMoney myMoneyTest2;
	public static MyMoney myMoneyTest3;
    private static int ParameterizedTestCounter;

    @BeforeAll
    public static void testSetup() { 
    	myMoneyTest1 = new MyMoney("values.txt", 8, 1);
    	myMoneyTest2 = new MyMoney("values.txt", "values2.txt", 8, 8);
    	myMoneyTest3 = new MyMoney("values2.txt", 8, 2);
    }
    
    @Test //Test 1
    void constructorTest1() { 
        Class<? extends MyMoney> temp = myMoneyTest1.getClass();
        String str = temp.getName();
        assertEquals("MyMoney", str);
    }
    
    @Test	//Test 2
    void constructorTest2() { 
        Class<? extends MyMoney> temp = myMoneyTest2.getClass();
        String str = temp.getName();
        assertEquals("MyMoney",str);
    }
    
    @Test	//Test 3
    void getInterestValuesTest1() { 
        assertNull(myMoneyTest1.getInterestValues());
    }
    
    @Test	//Test 4
    void getInterestValuesTest2() { 
        assertEquals(8, myMoneyTest3.getInterestValues().length);
    }	
    
    @Test	//Test 5
    void getInterestValuesTest3() { 
        assertEquals(.045, myMoneyTest3.getInterestValues()[2]);
    }
    @Test	//Test 6
    void getCashValuesTest1() { 
        assertNull(myMoneyTest3.getCashValues());
    }
    
    @Test	//Test 7
    void getCashValuesTest2() { 
        assertEquals(5500, myMoneyTest1.getCashValues()[1]);
    }
    
    @Test	//Test 8 
    void getCashValuesTest3() { 
    	assertEquals(8, myMoneyTest1.getCashValues().length);
    }
    
    @Test	//Test 9	
    void checkInterestArraysTest() { 
        double[] tmp = {.055,.075,.045,.09,.10,.065,.035,.025};
        assertArrayEquals(myMoneyTest3.getInterestValues(), tmp);
    }
    
    @Test	//Test 10
    void futureValueLumpSumTest() { 
        assertEquals(4220, Math.round(myMoneyTest2.lumpSum_ConstantRate(4000, .055,1)), "wrong output");
    }
    
    @Test	//Test 11
    void futureValueLS_VariableInterestTest() { 
        assertEquals(28899, Math.round(myMoneyTest2.lumpSum_VariableRate(18000)), "wrong output");
    }
    
    @Test	//Test 12
    void compoundSavingsConstantTest() { 
        assertEquals(4000, Math.round(myMoneyTest2.compoundSavings_sameContribution(4000, .065, 1)), "wrong output");
    }
    
    @Test	//Test 13
    void compoundSavingsVariableTest() { 
        assertEquals(109956, Math.round(myMoneyTest2.compoundSavings_variableContribution(.035)), "wrong output");
    }
    
    @ParameterizedTest	//Test 14
    @ValueSource(ints = {4000, 5500, 15000, 18000, 24000, 9000, 11000, 12000})
    void parameterizedTestForCashValues(int i) { 
        assertEquals(myMoneyTest1.getCashValues()[ParameterizedTestCounter], i, "wrong output");
        ParameterizedTestCounter++;
    }
    
    //Total test in MymoneyTest = 14
    //Total tests in both files 32
    
}
