/**************************
 *
 *  Project 1: Data Structure Library - GQ Testing
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;

//Test class that tests all the methods in GenericQueue and the 2 iterators from GenericList
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

public class GQTest {
    private GenericQueue<Integer> test1;

    @BeforeEach
    void setup() {
        test1 = new GenericQueue<>(23);
    }

    @AfterEach
    void teardown() {
        test1 = null;
    }

    @Test
    void constructorTest() {
        Class tmp = test1.getClass();
        String string = tmp.getName();
        assertEquals("GenericQueue", string);
    }

    @Test
    void enqueueTest() {
    	test1.enqueue(1);
    	Integer dequeueTes = test1.dequeue () ;
    	assertEquals (23, dequeueTes, "Enqueue method didn't work as expected.");
    }
    
    @Test
    void enqueueTest2() {
    	test1.enqueue(12);
    	Integer dequeueTes = test1.dequeue () ;
    	assertEquals (23, dequeueTes, "Enqueue method didn't work as expected.");
    }

    @Test
    void dequeueTest() {
    	Integer dequeueTes = test1.dequeue ();
    	assertEquals (23, dequeueTes, "Dequeue method didn't work as expected.");
    }
    
    @Test
    void addTest() {
    	test1.add(6);
    	assertEquals (Integer.valueOf(23),test1.get(0), "Add method didn't work as expected. ");
    	assertEquals (Integer.valueOf(6),test1.get(1), "Add method didn't work as expected. ");
    }
    @Test
    void addTest2() {
    	test1.add(30);
    	assertEquals (Integer.valueOf(23),test1.get(0), "Add method didn't work as expected. ");
    	assertEquals (Integer.valueOf(30),test1.get(1), "Add method didn't work as expected. ");
    }
    @Test
    void deleteTest() {
    	test1.add(7);
    	test1.delete();
    	assertEquals (Integer.valueOf(7),test1.get(0), "Delete method didn't work as expected. ");
    	assertEquals (null,test1.get(1), "Delete method didn't work as expected. ");
    }
    
    @Test
    void deleteTest2() {
    	test1.add(71);
    	test1.delete();
    	assertEquals (Integer.valueOf(71),test1.get(0), "Delete method didn't work as expected. ");
    	assertEquals (null,test1.get(1), "Delete method didn't work as expected. ");
    }
    
    @Test
    void GLIteratorTest() {
    	Iterator<Integer> GlTest = test1.iterator();
    	assertTrue(GlTest.hasNext());
    	assertEquals(Integer.valueOf(23), GlTest.next());
    	assertFalse(GlTest.hasNext());
    }
    
    @Test
    void descendingTest() {
    	Iterator<Integer> RGTest = test1.descendingIterator();
    	assertTrue(RGTest.hasNext());
    	assertEquals(Integer.valueOf(23), RGTest.next());
    	assertFalse(RGTest.hasNext());
    }
}

