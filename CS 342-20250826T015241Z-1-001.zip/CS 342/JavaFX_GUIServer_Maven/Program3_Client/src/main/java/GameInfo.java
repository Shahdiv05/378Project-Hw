import java.io.Serializable;

public class GameInfo implements Serializable {
    static final long serialVersionUID = 1357924680;

    private int wordLength = 0;
    private int guessesRemaining = 6;
    private boolean won = false;
    private boolean lost = false;
    private boolean wordGuessed = false;
    private String category;
    private String wordInProgress =  "";
    private String message;
    private char guess = ' ';


    public int getWordLength() {
        return wordLength;
    }

    public int getGuessesRemaining() {
        return guessesRemaining;
    }

    public boolean isWon() {
        return won;
    }

    public boolean isLost() {
        return lost;
    }

    public boolean isWordGuessed() {
        return wordGuessed;
    }

    public String getCategory() {
        return category;
    }

    public String getWordInProgress() {
        return wordInProgress;
    }

    public String getMessage() {
        return message;
    }

    public char getGuess() {
        return guess;
    }

    public void setWordLength(int length) {
        wordLength = length;
    }

    public void setGuessesRemaining(int guesses) {
        guessesRemaining = guesses;
    }

    public void setWon(boolean winning) {
        won = winning;
    }

    public void setLost (boolean losing) {
        lost = losing;
    }

    public void setWordGuessed (boolean word) {
        wordGuessed = word;
    }

    public void setCategory (String cat) {
        category = cat;
    }

    public void setWordInProgress (String str) {
        wordInProgress = str;
    }

    public void setMessage (String msg) {
        message = msg;
    }

    public void setGuess (char letter) {
        guess = letter;
    }
}

//import java.io.Serializable;
//
//public class GameInfo implements Serializable {
//    static final long serialVersionUID = 1357924680;
//
//    private int wordLength = 0;
//    private int guessesRemaining = 6;
//    private boolean won = false;
//    private boolean lost = false;
//    private boolean wordGuessed = false;
//    private String category;
//    private String wordInProgress =  "";
//    private String message;
//    private char guess = ' ';
//
//
//    public int getWordLength() {
//        return wordLength;
//    }
//
//    public int getGuessesRemaining() {
//        return guessesRemaining;
//    }
//
//    public boolean isWon() {
//        return won;
//    }
//
//    public boolean isLost() {
//        return lost;
//    }
//
//    public boolean isWordGuessed() {
//        return wordGuessed;
//    }
//
//    public String getCategory() {
//        return category;
//    }
//
//    public String getWordInProgress() {
//        return wordInProgress;
//    }
//
//    public String getMessage() {
//        return message;
//    }
//
//    public char getGuess() {
//        return guess;
//    }
//
//    public void setWordLength(int length) {
//        wordLength = length;
//    }
//
//    public void setGuessesRemaining(int guesses) {
//        guessesRemaining = guesses;
//    }
//
//    public void setWon(boolean winning) {
//        won = winning;
//    }
//
//    public void setLost (boolean losing) {
//        lost = losing;
//    }
//
//    public void setWordGuessed (boolean word) {
//        wordGuessed = word;
//    }
//
//    public void setCategory (String cat) {
//        category = cat;
//    }
//
//    public void setWordInProgress (String str) {
//        wordInProgress = str;
//    }
//
//    public void setMessage (String msg) {
//        message = msg;
//    }
//
//    public void setGuess (char letter) {
//        guess = letter;
//    }
//}
