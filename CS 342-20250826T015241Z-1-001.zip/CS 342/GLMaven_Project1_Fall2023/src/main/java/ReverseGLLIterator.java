/**************************
 *
 *  Project 1: Data Structure Library - ReverseGLLIterator
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import java.util.Iterator;

//This class is the same logic as the first iterator just goes opposite, reverse (tail to head).
//This is the class that will be returned when the descendingIterator() method is called in the GenericList class.

public class ReverseGLLIterator<E> implements Iterator<E> {
	
    GenericList<E>.Node<E> current; 
    GenericList<E>.Node<E> head; 
    GenericList<E>.Node<E> tail; 
    
    public ReverseGLLIterator(GenericList<E>.Node<E> head) { // constructor
        this.current = head; 
        while(current.getNext()!=null) { 
            current = current.getNext(); 
        }
        tail = current; 
        this.head = head;
    }
    
    
    @Override
    public boolean hasNext() {
        return tail!=null;	//returns true or false
    } 
    
    
    @Override
    public E next() {
        if (this.hasNext() == false) {
            return null;
        }
        current = head; 
        E tmp = tail.getData();
        if (tail == head){
            tail = null;
            return tmp; 
        }
        else {
        }
        
        while (current.getNext()!= tail){ 
            current = current.getNext(); 
        }
        tail = current;
        return tmp;
    }
}
