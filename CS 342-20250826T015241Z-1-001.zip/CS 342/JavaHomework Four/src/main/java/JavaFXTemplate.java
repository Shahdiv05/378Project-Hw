import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.layout.StackPane;
import javafx.geometry.Pos;

import java.util.Optional;

public class JavaFXTemplate extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("JavaFX College Welcome Demo");
        
        TextInputDialog inputText = new TextInputDialog();
        inputText.setHeaderText("Please enter your age:");	
        inputText.setContentText("Age:");

        Optional<String> result = inputText.showAndWait();
        if (result.isPresent()) {
            String inputAge = result.get();
            if (isAgeValid(inputAge)) {
                int age = Integer.parseInt(inputAge);

                StackPane root = new StackPane();

                if (age >= 18) {
                    ProxyRectangle proxyRectangle = new ProxyRectangle(100, 100, 100, 100);

                    Text collegeText = new Text("WELCOME TO COLLEGE!!");
                    collegeText.setFill(Color.BLUE);
                    collegeText.setFont(Font.font("Arial", 48));

                    StackPane.setAlignment(collegeText, Pos.TOP_CENTER);
                    root.getChildren().addAll(proxyRectangle.getRectangle(), collegeText);

                    proxyRectangle.playAnimations();
                } 
                else {
                    Alert alert = new Alert(AlertType.ERROR);
                    alert.setHeaderText("TOO YOUNG");
                    alert.setContentText("Sorry, you're not old enough for College yet.");
                    alert.showAndWait();
                }

                Scene scene = new Scene(root, 700, 700);
                primaryStage.setScene(scene);
            } 
            else {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setHeaderText("Invalid Input");
                alert.setContentText("Please enter a valid age...");
                alert.showAndWait();
            }
        }

        primaryStage.show();
    }

    private class ProxyRectangle {
        private Rectangle realRectangle;

        public ProxyRectangle(double x, double y, double width, double height) {
            realRectangle = new Rectangle(x, y, width, height);
            realRectangle.setArcHeight(50);
            realRectangle.setArcWidth(50);
            realRectangle.setFill(Color.GREEN);
        }

        public Rectangle getRectangle() {
            return realRectangle;
        }

        public void playAnimations() {
            RotateTransition rt = new RotateTransition(Duration.millis(5000), realRectangle);
            rt.setByAngle(270);
            rt.setCycleCount(4);
            rt.setAutoReverse(true);
            SequentialTransition seqTransition = new SequentialTransition(
                    new PauseTransition(Duration.millis(500)),
                    rt
            );

            seqTransition.play();

            FadeTransition ft = new FadeTransition(Duration.millis(5000), realRectangle);
            ft.setFromValue(1.0);
            ft.setToValue(0.3);
            ft.setCycleCount(4);
            ft.setAutoReverse(true);

            ft.play();
        }
    }

    boolean isAgeValid(String inputAge) {
        return isNumeric(inputAge) && Integer.parseInt(inputAge) >= 18 && Integer.parseInt(inputAge) <= 200;
    }

    boolean isNumeric(String str) {
        return str.matches("\\d+");
    }
}
