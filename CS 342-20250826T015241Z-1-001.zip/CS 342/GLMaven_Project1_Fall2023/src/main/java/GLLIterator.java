/**************************
 *
 *  Project 1: Data Structure Library - GLLIterator
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import java.util.Iterator;

//This class will be iterating through the strucutre. It is a generic class and will iterate through a generic linked list. 


public class GLLIterator<E> implements Iterator<E> {
    GenericList<E>.Node<E> head;
    
    public GLLIterator(GenericList<E>.Node<E> head) {
        this.head = head;
    }
    
    @Override
    public boolean hasNext() {	// returns true or false based on value of head
        return head != null;
    }
    
    @Override
    public E next() {		// returns temp based on value of head.next
        if(this.hasNext() == false) {
            return null;
        }
        E temp = head.getData();;
        head = head.getNext();
        return temp; 
    }
}
