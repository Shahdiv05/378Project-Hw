/**************************
 *
 *  Project 1: Data Structure Library - Generic List
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import java.util.ArrayList;
import java.util.ListIterator;
import  java.util.Iterator;

public abstract  class GenericList<T> implements Iterable{
	
	private Node<T> head;
    private int length; 
    
    public void print(){ 	//prints the items of the list, one value per line. If the list is empty, print “Empty List”
        if(length == 0){  
            System.out.println("Empty list");
            return;
        }
        Node<T> tmp = head; 
        while(tmp != null){
            System.out.println(tmp.data);
            tmp = tmp.next;
        }
    }
    
    public abstract void add(T data);	//adds the value to the list.
    
    public abstract T delete(); //deletes note, the list is empty, it should return null.
        
    
    public ArrayList<T> dumpList(){ 	//this method stores and returns all values currently in the list into an ArrayList and returns it.
        ArrayList<T> tmp = new ArrayList<T>(); 
        Node<T> temp = head;
        while(temp != null){
            tmp.add(temp.data); 
            temp = temp.next;
        }
        //temp.next = null;
//        head = null; // clears list contents
//        setLength(0); // sets list length to 0
        return tmp;
    }
    
    public T get(int index){	//returns the value at the specified index or null if the index is out of bounds.
        if(index >= length){ 
            return null;
        }
        Node<T> tmp = head;
        int i = 0;
        while(i < index){  
            tmp= tmp.next;
            i++;
        }
        return tmp.data; 
    }
    
    public T set(int index, T element){ //switches the element at a certain spot with the given node
        if(index >= length){
            return null;
        }
        Node<T> tmp = head;
        int i = 0;
        while(i < index){
            tmp = tmp.next;
            i++;
        }
        T check = tmp.data; 
        tmp.data = element; 
        return check; 
    }
    
    public int getLength(){	//getter for getting the lenght
        return length; 
    }
    public void setLength(int length){		//setter for setting the length
        this.length = length;
    }
    public Node<T> getHead(){		//getter for getting the head
        return head; 
    }
    public void setHead(Node<T> head){		//setter for setting head
        this.head = head; 
    }
      
    public class Node<T>{ 	//Node class data contains the data being stored in the list
        private T data;
        int code;	//used in the genericqueue add method and on line 101
        private Node<T> next;	//will be the reference to the next node in the list.

        public Node(T val){
            data = val; 
            this.data = val;
            this.next = null;
        }
        public Node(T val, int code){
            data = val; 
            this.data = val;
            this.next = null;
            this.code = code;
        }
        public T getData(){
            return data;
        }
        public Node<T> getNext(){
            return next; 
        }
        public void setNext(Node<T> nextNode){
            next = nextNode;  
        }
        
        public void setData(T data){
            this.data = data; 
        }

    }
    
    public Iterator<T> iterator(){ 	//iterator for GLLIterator, tested in test class.
        return new GLLIterator<T>(head);
    }
    
    public Iterator<T> descendingIterator(){	//returns an iterator over the elements of the list in reverse order( tail to head)
        return new ReverseGLLIterator<T>(head);
    }
    
}

