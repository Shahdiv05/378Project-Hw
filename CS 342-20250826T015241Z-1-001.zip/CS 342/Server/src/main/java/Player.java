import java.util.HashSet;
import java.util.Set;

public class Player {
    private String playerName;
    private Set<Character> guessedLetters;
    private int guessesLeft;
    private int wordsGuessed;
    private Category currentCategory;

    public Player(String playerName) {
    	this.playerName = playerName;
        this.guessedLetters = new HashSet<>();
        this.guessesLeft = WordGuessGame.MAX_GUESSES;
        this.wordsGuessed = 0;
    }

    public boolean makeGuess(char letter) {
        if (!guessedLetters.contains(letter)) {
            guessedLetters.add(letter);
            guessesLeft--;

            // Check if the guessed letter is in the current word
            boolean isCorrectGuess = currentCategory.getCurrentWord().indexOf(letter) != -1;

            if (isCorrectGuess) {
                // Handle correct guess logic (e.g., update GUI)
            } else {
                // Handle incorrect guess logic (e.g., update GUI)
            }

            return isCorrectGuess;
        } else {
            // Letter has already been guessed
            return false;
        }
    }

    public void chooseCategory(Category category) {
        currentCategory = category;
        category.setCurrentWord(category.getNextWord());
        resetGuesses();
    }

    public void chooseNextWord() {
        currentCategory.setCurrentWord(currentCategory.getNextWord());
        resetGuesses();
    }

    public boolean hasGuessesLeft() {
        return guessesLeft > 0;
    }

    public boolean isWordGuessed() {
        return currentCategory.getCurrentWord().chars()
                .allMatch(c -> guessedLetters.contains((char) c));
    }

    public void resetGuesses() {
        guessedLetters.clear();
        guessesLeft = WordGuessGame.MAX_GUESSES;
    }
}
