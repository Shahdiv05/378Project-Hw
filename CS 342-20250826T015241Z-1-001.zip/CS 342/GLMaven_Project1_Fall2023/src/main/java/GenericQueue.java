/**************************
 *
 *  Project 1: Data Structure Library - Generic Queue
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import java.util.Iterator;


public class GenericQueue<T> extends GenericList<T> {
	private Node<T> tail;	//This is a traditional reference to the tail of the list.
	
	
	public GenericQueue(T val) { // constructor
        Node<T> tempVal = new Node<T>(val); 
        setHead(tempVal); 
        tail = tempVal;
        setLength(1); 
    }
	
	public void add(T data) { 	//add method to add to the back of the queue
		Node<T> node = new Node<T>(data);
//        tail.setNext(node);
//        tail = node;
//        setLength(getLength() + 1);
		if(getLength() == 0) {
			setHead(node);
		}
		else {
			tail.setNext(node);
		}
		tail = node;
		setLength(getLength() + 1);
		//tail = node;
    }
	
	public T delete() {		//It will return the value of and delete the last node in the list
		if(getLength() == 0) {
			return null;
		}
		T data = getHead().getData();
		setHead(getHead().getNext());
		if(getHead() == null) {
			tail = null;
		}
		//tail = null;
		setLength(getLength() - 1);
		return data;
	}
	
    public void enqueue(T data) {	//calls the add method and adds to the list
        add(data);
    }
    
    public T dequeue() {	//calls to the delete method and deletes from the list
        return delete();
     }
    
	public void add(T data, int code) { 	//add method to add to the back of the queue, using int code, other then that excat same function as before. 
		Node<T> node = new Node<T>(data, code);
//        tail.setNext(node);
//        tail = node;
//        setLength(getLength() + 1);
		if(getLength() == 0) {
			setHead(node);
		}
		else {
			tail.setNext(node);
		}
		tail = node;
		setLength(getLength() + 1);
		//tail = node;
    }
}
