import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class JavaFXTemplate extends Application {

    @FXML
    private TextField centerTextField;

    @FXML
    private TextField rightTextField;

    @FXML
    private Button button1;

    @FXML
    private Button button2;

    @FXML
    private BorderPane borderPane;

    @FXML
    private VBox buttonVBox;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/HW3Fall23.fxml"));

        Scene scene = new Scene(root);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());

        stage.setTitle("Divya Shah Homework 3");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void initialize() {
        centerTextField.setPromptText("enter text here then press button 1");
        rightTextField.setEditable(false);
        rightTextField.setText("final string goes here");
    }

    @FXML
    private void handleButton1Click(ActionEvent event) {
        String centerText = centerTextField.getText();
        String newText = centerText + " : from the center text field!";
        rightTextField.setText(newText);
        button1.setDisable(true);
        button1.setText("pressed");
    }

    @FXML
    private void handleButton2Click(ActionEvent event) {
        centerTextField.clear();
        rightTextField.clear();
        rightTextField.setText("final string goes here");
        button1.setDisable(false);
        button1.setText("button 1");
    }
}
