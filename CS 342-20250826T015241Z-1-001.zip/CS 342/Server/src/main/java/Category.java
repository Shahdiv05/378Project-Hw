import java.util.List;
import java.util.Random;

public class Category {
    private String name;
    private List<String> words;
    private String currentWord;
    private int wordIndex;

    public Category(String name, List<String> words) {
        this.name = name;
        this.words = words;
        this.wordIndex = 0;
        this.currentWord = getNextWord();
    }

    public String getNextWord() {
        if (wordIndex < words.size()) {
            return words.get(wordIndex++);
        } else {
            return null; // All words in the category have been used
        }
    }

    public Category setCurrentWord(String word) {
        this.currentWord = word;
        return this; // Return this for method chaining
    }

    public String getCurrentWord() {
        return currentWord;
    }

    public String getName() {
        return name;
    }

    // Method to choose a random word (unused, as per the provided UML)
    public String getRandomWord() {
        Random random = new Random();
        int randomIndex = random.nextInt(words.size());
        return words.get(randomIndex);
    }
}
