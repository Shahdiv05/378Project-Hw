//import static org.junit.jupiter.api.Assertions.*;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//class MyTest {
//    
//    private GameLogic gameLogic;
//
//    @BeforeEach
//    public void setUp() {
//        gameLogic = new GameLogic();
//        gameLogic.PopulateWordLists();
//    }
//
//    @Test
//    public void testPickWord() {
//        // Test picking a word for each category
//        gameLogic.currCategory = "Animals";
//        gameLogic.pickWord();
//        assertNotNull(gameLogic.getCurrWord());
//
//        gameLogic.currCategory = "Cities";
//        gameLogic.pickWord();
//        assertNotNull(gameLogic.getCurrWord());
//
//        gameLogic.currCategory = "Sports";
//        gameLogic.pickWord();
//        assertNotNull(gameLogic.getCurrWord());
//    }
//
//    @Test
//    public void testCorrectGuess() {
//        gameLogic.currCategory = "TestCategory";
//        gameLogic.currWord = "test";
//        gameLogic.wordGuessWithDashes = "----";
//
//        // Test correct guess
//        assertTrue(gameLogic.correctGuess('t', "----"));
//        assertEquals("t---", gameLogic.wordGuessWithDashes);
//
//        // Test incorrect guess
//        assertFalse(gameLogic.correctGuess('x', "t---"));
//        assertEquals("t---", gameLogic.wordGuessWithDashes);
//    }
//
//    @Test
//    public void testIsWinning() {
//        // Test winning condition
//        gameLogic.categoriesWon = 2;
//        assertFalse(gameLogic.isWinning());
//
//        gameLogic.categoriesWon = 3;
//        assertTrue(gameLogic.isWinning());
//    }
//
//    @Test
//    public void testIsLosing() {
//        // Test losing condition
//        gameLogic.Nations.clear();
//        gameLogic.Colors.clear();
//        gameLogic.Sports.clear();
//        assertFalse(gameLogic.isLosing());
//
//        // Remove words from one category to simulate losing
//        gameLogic.Nations.remove(0);
//        gameLogic.Nations.remove(0);
//        gameLogic.Nations.remove(0);
//        assertTrue(gameLogic.isLosing());
//    }
//}
