import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class MyController implements Initializable {
    static Client clientConnection;
    GameInfo gameInfo = new GameInfo();
    @FXML
    private AnchorPane root;

    @FXML
    private AnchorPane root2;

    @FXML
    private AnchorPane root3;

    @FXML
    private Text WrongInput;

    @FXML
    private TextField IP;

    @FXML
    private TextField Port;

    @FXML
    private Button GuessesRemaining;

    @FXML
    private TextField UserInput;

    @FXML
    private Text WordToGuess;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // TODO Auto-generated method stub
    }

    public void ConnectController(ActionEvent e) throws IOException {
        clientConnection = new Client(data-> {Platform.runLater(()-> updateGameInfo(clientConnection.gameInfo));}, Integer.parseInt(Port.getText()));
        callStart();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/Myfxml2.fxml"));
        Parent root2 = loader.load();
        root.getScene().setRoot(root2);
    }

    public void callStart() {
        clientConnection.start();
    }
    private void updateGameInfo(GameInfo info) {
        gameInfo = info;
    }

    public void ExitController(ActionEvent e) throws IOException {
        Platform.exit();
        System.exit(1);
    }

    public void AnimalController(ActionEvent e) throws IOException {
        gameInfo.setCategory("Animals");
        clientConnection.send(gameInfo);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/Myfxml3.fxml"));
        Parent root3 = loader.load();

        MyController3 myController3 = loader.getController();
        myController3.updateWordToGuess(clientConnection.gameInfo.getWordInProgress());
        myController3.getGameInfoAndClient(gameInfo, clientConnection);

//        while(true) {
//            if(APIProcess) {
//                WordToGuess.setText(clientConnection.gameInfo.getWordInProgress());
//                break;
//            }
//        }
//        WordToGuess.setText(clientConnection.gameInfo.getWordInProgress());
//
//        System.out.println(WordToGuess.getText());
//        System.out.println(clientConnection.gameInfo.getWordInProgress());
        root2.getScene().setRoot(root3);
//        WordToGuess = new Text(clientConnection.gameInfo.getWordInProgress());
//        System.out.println(clientConnection.gameInfo.getWordInProgress());
//        WordToGuess.setText(clientConnection.gameInfo.getWordInProgress());
    }

    public void SportsController(ActionEvent e) throws IOException {
        gameInfo.setCategory("Sports");
        clientConnection.send(gameInfo);
        WordToGuess.setText(gameInfo.getWordInProgress());
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/Myfxml3.fxml"));
        Parent root3 = loader.load();
        root2.getScene().setRoot(root3);
    }

    public void CitiesController(ActionEvent e) throws IOException {
        gameInfo.setCategory("Cities");
        clientConnection.send(gameInfo);
        WordToGuess.setText(gameInfo.getWordInProgress());
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/Myfxml3.fxml"));
        Parent root3 = loader.load();
        WordToGuess.setText(clientConnection.gameInfo.getWordInProgress());
        root2.getScene().setRoot(root3);
    }

}