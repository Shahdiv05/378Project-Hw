import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import gaussian_kde

def prepare_ml_data(merged_df):
    df = merged_df.copy()
    X = df[['2024_Median_Income', 'Station_Count', 'Avg_Electric_Range']].fillna(0)
    y = df['EV_Count']
    return X, y

def baseline_model(y):
    mean_val = y.mean()
    preds = [mean_val] * len(y)
    mse = mean_squared_error(y, preds)
    return preds, mse

def linear_regression_model(X, y):
    model = LinearRegression()
    model.fit(X, y)
    preds = model.predict(X)
    mse = mean_squared_error(y, preds)
    r2 = r2_score(y, preds)
    return model, preds, mse, r2

def get_regression_metrics(df):
    X, y = prepare_ml_data(df)
    _, baseline_mse = baseline_model(y)
    model, preds, regression_mse, r2 = linear_regression_model(X, y)
    features = ['Income', 'Stations', 'Avg_Range']
    coef_dict = dict(zip(features, model.coef_))
    return {
        'baseline_mse': baseline_mse,
        'regression_mse': regression_mse,
        'r2': r2,
        'coefficients': coef_dict
    }

def print_regression_summary(df):
    m = get_regression_metrics(df)
    print(f"Baseline MSE: {m['baseline_mse']:.1f}")
    print(f"Regression MSE: {m['regression_mse']:.1f}")
    print(f"R²: {m['r2']:.3f}")
    print("Coefficients:")
    for feat, coef in m['coefficients'].items():
        print(f"  {feat}: {coef:.3f}")

def plot_ev_and_stations_vs_income(df):
    df2 = df.copy()
    df2['Income_num'] = pd.to_numeric(df2['2024_Median_Income'], errors='coerce')
    X, y = prepare_ml_data(df)
    model, preds, mse, r2 = linear_regression_model(X, y)
    df2 = df2.assign(Predicted_EV=preds).sort_values('Income_num')
    fig, ax1 = plt.subplots(figsize=(12, 4))
    ax2 = ax1.twinx()
    ax1.plot(
        df2['Income_num'], df2['EV_Count'],
        color='teal', marker='o', linewidth=2, label='Actual EVs'
    )
    ax1.plot(
        df2['Income_num'], df2['Predicted_EV'],
        color='orange', linestyle='--', linewidth=2, label='Regression Fit'
    )
    ax1.set_ylabel('EV_Count', color='teal')
    ax1.tick_params(axis='y', labelcolor='teal')
    ax2.plot(
        df2['Income_num'], df2['Station_Count'],
        color='purple', marker='s', linewidth=2, label='Charging Stations'
    )
    ax2.set_ylabel('Station_Count', color='purple')
    ax2.tick_params(axis='y', labelcolor='purple')
    ax1.set_xlabel('Median Income (2024)')
    ax1.set_xlim(40000, 130000)
    ax1.set_title('EV Registrations & Charging Stations vs. Income (2024)')
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(
        lines1 + lines2,
        labels1 + labels2,
        loc='upper left',
        bbox_to_anchor=(1.3, 1),
        borderaxespad=0
    )
    plt.tight_layout(rect=[0, 0, 0.75, 1])
    plt.show()

def compute_wcss(df, max_k=6):
    features = df[['EV_Count', '2024_Median_Income', 'Station_Count']]
    scaler = StandardScaler()
    X = scaler.fit_transform(features)
    wcss = {}
    for k in range(1, max_k + 1):
        km = KMeans(n_clusters=k, random_state=42)
        km.fit(X)
        wcss[k] = km.inertia_
    return wcss

def plot_elbow(df, max_k):
    wcss = compute_wcss(df, max_k=max_k)
    ks = list(wcss.keys())
    vals = [wcss[k] for k in ks]
    plt.figure(figsize=(6,3))
    plt.plot(ks, vals, marker='o')
    plt.title("Elbow Method (WCSS vs. # of clusters)")
    plt.xlabel("Number of clusters k")
    plt.ylabel("WCSS")
    plt.xticks(ks)
    plt.grid(True)
    plt.tight_layout()
    plt.show()

def perform_clustering(df, n_clusters=3):
    features = df[['EV_Count', '2024_Median_Income', 'Station_Count']]
    scaler = StandardScaler()
    X = scaler.fit_transform(features)
    km = KMeans(n_clusters=n_clusters, random_state=42)
    df = df.copy()
    df['Cluster'] = km.fit_predict(X)
    return df

def print_elbow_summary(df, max_k=6, drop_threshold=0.05):
    wcss = compute_wcss(df, max_k=max_k)
    wcss1 = wcss[1]
    var_explained = {k: 1 - (wcss[k] / wcss1) for k in wcss}
    optimal_k = max_k
    for k in range(2, max_k + 1):
        delta = var_explained[k] - var_explained[k-1]
        if delta < drop_threshold:
            optimal_k = k - 1
            break
    print(" k |  WCSS   |  Variance Explained")
    print("---|---------|----------")
    for k in range(1, max_k + 1):
        print(f"{k:2d} | {wcss[k]:7.0f} | {var_explained[k]*100:7.1f}%")
    drop_pct = var_explained[optimal_k] * 100
    print(f"\n Elbow detected at k = {optimal_k}, explaining {drop_pct:.1f}% of variance")
    return optimal_k

def plot_kmeans_clusters(clustered_df, n_clusters=3):
    features = clustered_df[['EV_Count', '2024_Median_Income', 'Station_Count']]
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(features)
    km = KMeans(n_clusters=n_clusters, random_state=42)
    km.fit(X_scaled)
    centroids_scaled = km.cluster_centers_
    centroids = scaler.inverse_transform(centroids_scaled)
    ev_centroids = centroids[:, 0]
    income_centroids = centroids[:, 1]
    order = np.argsort(income_centroids)
    labels = ['Low-Adoption', 'Mid-Adoption', 'High-Adoption']
    name_map = {orig: labels[i] for i, orig in enumerate(order)}
    fig, ax = plt.subplots(figsize=(12, 5))
    cmap = plt.get_cmap('tab10', n_clusters)
    scatter = ax.scatter(
        clustered_df['2024_Median_Income'],
        clustered_df['EV_Count'],
        c=clustered_df['Cluster'],
        s=clustered_df['Station_Count'] * 10,
        cmap=cmap,
        alpha=0.7
    )
    for idx, (ev_c, inc_c) in enumerate(zip(ev_centroids, income_centroids)):
        ax.scatter(
            inc_c, ev_c,
            marker='X', s=200,
            c=[cmap(idx)], edgecolor='k', linewidth=1.5
        )
        ax.annotate(
            name_map[idx],
            (inc_c, ev_c),
            textcoords="offset points", xytext=(5,5),
            ha='left', fontsize=9, fontweight='bold'
        )
    ax.set_title("K-Means Clustering of Counties\n(Bubble size ∝ Station_Count)")
    ax.set_xlabel('Median Income (2024)')
    ax.set_ylabel('EV Count')
    ax.set_xlim(0, 150000)
    ax.set_ylim(0, 150000)
    ax.grid(True)
    ax.legend(
        *scatter.legend_elements(),
        title='Cluster',
        loc='upper left',
        bbox_to_anchor=(1.02, 1),
        borderaxespad=0
    )
    plt.tight_layout(rect=[0,0,0.85,1])
    plt.show()

def plot_residuals_ridge_by_station_quintile(df, n_quintiles=5):
    X, y = prepare_ml_data(df)
    model, preds, mse, r2 = linear_regression_model(X, y)
    df2 = df.copy()
    df2['Predicted'] = preds
    df2['Residual'] = df2['EV_Count'] - df2['Predicted']
    labels = [f"Q{i+1}" for i in range(n_quintiles)]
    df2['Station_Quintile'] = pd.qcut(
        df2['Station_Count'], q=n_quintiles, labels=labels
    )
    r_min, r_max = df2['Residual'].min(), df2['Residual'].max()
    r_vals = np.linspace(r_min, r_max, 200)
    fig, ax = plt.subplots(figsize=(8,6))
    offsets = np.arange(n_quintiles) * 0.5
    for i, lab in enumerate(labels):
        group = df2[df2['Station_Quintile'] == lab]['Residual']
        if len(group) < 2:
            continue
        kde = gaussian_kde(group)
        dens = kde(r_vals)
        dens = dens / dens.max() * 0.4
        ax.fill_between(r_vals, offsets[i], offsets[i] + dens, alpha=0.6, label=lab)
        ax.plot(r_vals, offsets[i] + dens, linewidth=1)
    ax.set_yticks(offsets + 0.2)
    ax.set_yticklabels(labels)
    ax.set_xlabel("Residual (Actual – Predicted EV_Count)")
    ax.set_title("Regression Residuals by Station‐Count Quintile")
    ax.legend(
        title="Station Quintile",
        loc="upper left",
        bbox_to_anchor=(1.02, 1),
        borderaxespad=0
    )
    plt.tight_layout(rect=[0,0,0.85,1])
    plt.axvline(0, linestyle='--', linewidth=1)
    plt.show()
