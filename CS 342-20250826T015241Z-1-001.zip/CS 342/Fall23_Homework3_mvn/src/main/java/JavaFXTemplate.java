import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {

    private Button createButton(String color) {
        Button button = new Button(color);
        button.setOnAction(e -> handleButtonClick(button));
        return button;
    }

    private void handleButtonClick(Button button) {
        String color = button.getText();
        String pressedLabel = color + " Pressed";

        // Set background color
        button.getScene().getRoot().setStyle("-fx-background-color: " + color.toLowerCase());

        // Set button label
        button.setText(pressedLabel);

        // Reset other buttons
        for (Node node : ((StackPane) button.getScene().getRoot()).getChildren()) {
            if (node instanceof Button && node != button) {
                Button otherButton = (Button) node;
                otherButton.setText(otherButton.getText().replace(" Pressed", ""));
            }
        }
    }

    @Override
    public void start(Stage primaryStage) {
        Button greenButton = createButton("Green");
        Button yellowButton = createButton("Yellow");
        Button redButton = createButton("Red");

        StackPane root = new StackPane();
        root.getChildren().addAll(greenButton, yellowButton, redButton);

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("Color Changer App");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

//import javafx.application.Application;
//import javafx.scene.Scene;
//import javafx.scene.layout.VBox;
//import javafx.stage.Stage;
//import javafx.scene.control.Button;
//import javafx.scene.layout.BorderPane;
//import javafx.scene.control.TextField;
//import javafx.event.ActionEvent;
//import javafx.event.EventHandler;
//import javafx.geometry.Insets;
//import javafx.scene.paint.Color;
//
//public class JavaFXTemplate extends Application {
//    private Button button1;
//    private Button button2;
//    private TextField text1;
//    private TextField text2;
//    private BorderPane borderPane;
//    private VBox box;
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//
//    @Override
//    public void start(Stage primaryStage) throws Exception {
//        primaryStage.setTitle("Divya Shah Homework 3");
//        button1 = new Button("Button 1");
//        button2 = new Button("Button 2");
//
//        text1 = new TextField();
//        text2 = new TextField();
//
//        box = new VBox(20, button1, button2);
//
//        text1.setPromptText("enter text here then press button 1");
//        text2.setEditable(false);
//        text2.setText("final string goes here");
//
//        button1.setPrefSize(250, 150);
//        button2.setPrefSize(250, 150);
//
//        text1.setPrefSize(250, 150);
//        text2.setPrefSize(250, 150);
//
//        borderPane = new BorderPane();
//        borderPane.setCenter(text1);
//        borderPane.setRight(text2);
//        borderPane.setLeft(box);
//        borderPane.setPadding(new Insets(5, 10, 5, 10));
//
//        EventHandler<ActionEvent> handler = new EventHandler<ActionEvent>() {
//            public void handle(ActionEvent actionEvent) {
//                String cText = text1.getText() + " : from the center text field!";
//                text2.setText(cText);
//                button1.setDisable(true);
//                button1.setText("pressed");
//                button1.setTextFill(Color.BLUE);	//sets the text color to blue
//                button2.setTextFill(Color.RED);		//sets the text color to red
//            }
//        };
//
//        button2.setOnAction(actionEvent ->
//        {
//            text1.clear();
//            text2.clear();
//            text2.setText("final string goes here");
//            button1.setDisable(false);
//            button1.setText("button one");
//        });
//
//        button1.setOnAction(handler);
//
//        // Set the background color of the borderPane to orange
//        borderPane.setStyle("-fx-background-color: orange;");
//
//        Scene scene = new Scene(borderPane, 700, 700);
//        primaryStage.setScene(scene);
//        primaryStage.show();
//    }
//}
