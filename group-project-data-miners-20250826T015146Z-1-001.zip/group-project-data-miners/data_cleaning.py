import pandas as pd

def load_datasets(ev_path, income_path, stations_path):
    df_ev = pd.read_csv(ev_path)
    df_income = pd.read_csv(income_path)
    df_stations = pd.read_csv(stations_path)
    return df_ev, df_income, df_stations

def clean_ev_data(df):
    df = df.drop_duplicates()
    df['County'] = df['County'].astype(str).str.strip()
    df['Electric Range'] = pd.to_numeric(df['Electric Range'], errors='coerce')
    return df

def aggregate_ev_data(df):
    rows = []
    counties = df['County'].unique()
    for county in counties:
        sub = df[df['County'] == county]
        ev_count = sub['VIN (1-10)'].count()
        avg_range = sub['Electric Range'].mean()
        makes = sub['Make'].value_counts()
        common_make = makes.index[0] if len(makes) > 0 else ''
        types = sub['Electric Vehicle Type'].value_counts()
        common_type = types.index[0] if len(types) > 0 else ''
        rows.append({
            'County': county,
            'EV_Count': ev_count,
            'Avg_Electric_Range': avg_range,
            'Most_Common_Make': common_make,
            'Most_Common_Electric_Vehicle_Type': common_type
        })
    return pd.DataFrame(rows)

def clean_income_data(df):
    df['County'] = df['County'].astype(str).str.strip()
    rename_map = {}
    if '2020' in df.columns:
        rename_map['2020'] = 'Median_Income_2020'
    if '2021' in df.columns:
        rename_map['2021'] = 'Median_Income_2021'
    if '2022' in df.columns:
        rename_map['2022'] = 'Median_Income_2022'
    if '2023' in df.columns:
        rename_map['2023'] = 'Median_Income_2023'
    if '2024' in df.columns:
        rename_map['2024'] = 'Median_Income_2024'
    df = df.rename(columns=rename_map)
    return df

def clean_stations_data(df):
    df = df.dropna(subset=['Latitude', 'Longitude'])
    df['county'] = df['county'].astype(str).str.strip()
    df['county'] = df['county'].str.replace(' County', '')
    return df

def get_station_counts(df):
    counts = {}
    for c in df['county']:
        c2 = c.strip()
        c2 = c2.replace(' County', '')
        if c2 not in counts:
            counts[c2] = 0
        counts[c2] += 1
    rows = []
    for county, count in counts.items():
        rows.append({'County': county, 'Station_Count': count})
    return pd.DataFrame(rows)

def merge_data(ev_agg, income, stations):
    m1 = pd.merge(ev_agg, income, on='County', how='inner')
    m2 = pd.merge(m1, stations, on='County', how='left')
    m2['Station_Count'] = m2['Station_Count'].fillna(0)
    for y in ['2024', '2023', '2022', '2021', '2020']:
        col = 'Median_Income_' + y
        if col in m2.columns:
            newcol = y + '_Median_Income'
            vals = m2[col].str.replace('$', '').str.replace(',', '')
            m2[newcol] = vals.astype(float)
            m2 = m2.drop(columns=[col])
    return m2