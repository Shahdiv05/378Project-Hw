import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def eda_summary(df):
    print("Data Information:")
    info = df.info()
    print(info)
    print("Data Summary:")
    summary = df.describe()
    print(summary)

def plot_ev_count(df):
    df_sorted = df.sort_values(by="EV_Count", ascending=False)
    top10 = df_sorted.head(10)
    counties = list(top10["County"])
    counts = list(top10["EV_Count"])
    plt.figure(figsize=(8, 5))
    sns.barplot(x=counties, y=counts)
    plt.title("Top 10 Counties by EV Count")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def plot_station_counts_horizontal(df):
    df_sorted = df.sort_values(by="Station_Count", ascending=False)
    top10 = df_sorted.head(10)
    counties = list(top10["County"])
    counts = list(top10["Station_Count"])
    plt.figure(figsize=(8, 5))
    sns.barplot(y=counties, x=counts)
    plt.title("Top 10 Counties by Charging Station Count")
    plt.xlabel("Station Count")
    plt.ylabel("County")
    plt.tight_layout()
    plt.show()

def plot_ev_vs_station(df):
    x = list(df["Station_Count"])
    y = list(df["EV_Count"])
    plt.figure(figsize=(8, 5))
    plt.scatter(x, y)
    plt.title("EV Count vs Charging Station Count")
    plt.xlabel("Station Count")
    plt.ylabel("EV Count")
    plt.grid(True)
    plt.tight_layout()
    plt.show()
