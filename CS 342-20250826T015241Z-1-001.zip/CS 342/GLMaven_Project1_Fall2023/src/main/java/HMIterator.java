/**************************
 *
 *  Project 1: Data Structure Library - HM Iterator
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import java.util.Iterator;
//They will work in a similar fashion to the others in GLLIterator and ReverseGLLIterator except they will know how to iterate through your hash map
//If this was done properly with is not in my case, it would work the same as the first 2 iterators, only difference instead of linked list it would be going through my Map.
public class HMIterator<K, V> implements Iterator<V> {
	
//	public HMIterator(MYHashMap<K, V> hashMap) {
//	       
//	}
	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public V next() {
		// TODO Auto-generated method stub
		return null;
	}

}
