import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import java.util.HashSet;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {

	// Tests for Card class
		
	@Test
	void testCard() {
		Card hearts = new Card("Hearts",8);
		Card spades = new Card("Spades",5);

		assertEquals(8, hearts.value, "Incorrect card number");
		assertEquals(5, spades.value, "Incorrect card number");
	}

	@Test
	void testCard1() {
		Card diamonds = new Card("Diamonds",1);
		Card clubs = new Card("Clubs",2);

		assertEquals(1, diamonds.value, "Incorrect card number");
		assertEquals(2, clubs.value, "Incorrect card number");		
	}
	
	
	//Next tests will be for BaccaratGameLogic
	//2 tests for whoWon()
	@Test
	void whoWonTest(){
		BaccaratGameLogic logic = new BaccaratGameLogic();
		Card card1 = new Card("Clubs",4);
		Card card2 = new Card("Hearts",5);

		Card card3 = new Card("Spades",1);
		Card card4 = new Card("Diamonds",2);

		ArrayList<Card> hand1 = new ArrayList<>();
		ArrayList<Card> hand2 = new ArrayList<>();

		hand1.add(card1);
		hand1.add(card2);

		hand2.add(card3);
		hand2.add(card4);

		String winner = logic.whoWon(hand1,hand2);

		assertEquals("Banker",winner,"Incorrect winner");
	}
	
    @Test
    void whoWonTest2() {
        BaccaratGameLogic gameLogic = new BaccaratGameLogic();

        ArrayList<Card> playerHand = new ArrayList<>();
        playerHand.add(new Card("Hearts", 7));
        playerHand.add(new Card("Clubs", 8));

        ArrayList<Card> bankerHand = new ArrayList<>();
        bankerHand.add(new Card("Diamonds", 5));
        bankerHand.add(new Card("Spades", 4));

        String result = gameLogic.whoWon(playerHand, bankerHand);
        assertEquals("Player", result, "Incorrect winner");
    }
    
    
    //2 tests for Handtotal
	@Test
	void handTotalTest(){
		BaccaratGameLogic logic = new BaccaratGameLogic();
		Card card1 = new Card("Clubs",4);
		Card card2 = new Card("Hearts",12);
		Card card3 = new Card("Spades",7);
		Card card4 = new Card("Diamonds",9);

		ArrayList<Card> hand1 = new ArrayList<>();
		ArrayList<Card> hand2 = new ArrayList<>();

		hand1.add(card1);
		hand1.add(card2);
		hand2.add(card3);
		hand2.add(card4);

		assertEquals(4,logic.handTotal(hand1), "Incorrect");
		assertEquals(6,logic.handTotal(hand2), "Incorrect");
	}
	
    @Test
    void handTotalTest2() {
        BaccaratGameLogic gameLogic = new BaccaratGameLogic();

        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 7));
        hand.add(new Card("Clubs", 8));

        int total = gameLogic.handTotal(hand);
        assertEquals(5, total, "Incorrect total value for the given hand");
    }
    
    //2 Tests for evaluateBankerDraw()
    @Test
	void evaluateBankerDraw1(){
		BaccaratGameLogic logic = new BaccaratGameLogic();
		Card card1 = new Card("Hearts",7);
		Card card2 = new Card("Clubs",5);
		Card card3 = new Card("Diamonds",2);
		Card card4 = new Card("Hearts",1);

		ArrayList<Card> hand1 = new ArrayList<>();
		ArrayList<Card> hand2 = new ArrayList<>();

		hand1.add(card1);
		hand1.add(card2);

		hand2.add(card3);
		hand2.add(card4);

		assertTrue(logic.evaluateBankerDraw(hand2,card4),"Draw");
		assertTrue(logic.evaluateBankerDraw(hand1,card2),"Don't draw");
	}
    
	@Test
	void evaluateBankerDraw2(){
		BaccaratGameLogic logic = new BaccaratGameLogic();
		Card card1 = new Card("Hearts",2);
		Card card2 = new Card("Clubs",9);
		Card card3 = new Card("Diamonds",4);
		Card card4 = new Card("Spades",5);

		ArrayList<Card> hand1 = new ArrayList<>();
		ArrayList<Card> hand2 = new ArrayList<>();

		hand1.add(card1);
		hand1.add(card2);

		hand2.add(card3);
		hand2.add(card4);

		assertTrue(logic.evaluateBankerDraw(hand1,card1),"Don't draw");
		assertFalse(logic.evaluateBankerDraw(hand2,card3),"Don't draw");
	}
	
	//2 Test for evaluatePlayerDraw()
	@Test
	void evaluatePlayerDrawTest1() {
		BaccaratGameLogic logic = new BaccaratGameLogic();
		Card spades = new Card("Spades",4);
		Card clubs = new Card("Clubs",3);

		ArrayList<Card> hand = new ArrayList<>();
		hand.add(spades);
		hand.add(clubs);

		assertFalse(logic.evaluatePlayerDraw(hand),"Don't draw");
	}
	
	@Test
	void evaluatePlayerDrawTest2() {
		BaccaratGameLogic logic = new BaccaratGameLogic();

		Card hearts = new Card("Hearts",8);
		Card diamonds = new Card("Diamonds",3);

		ArrayList<Card> hand = new ArrayList<>();
		hand.add(hearts);
		hand.add(diamonds);

		assertTrue(logic.evaluatePlayerDraw(hand),"Draw");
	}
	
	
	//Next tests will be for BaccaratDealer
	//2 Tests for generateDeck
    @Test
    public void generateDeckTest1() {
        BaccaratDealer dealer = new BaccaratDealer();

        // Generating the deck
        dealer.generateDeck();

        assertEquals(52, dealer.deckSize(), "Generated deck should have 52 cards");
    }
    
    
    @Test
    public void generateDeckTest2() {
        BaccaratDealer dealer = new BaccaratDealer();

        // Generating the deck
        dealer.generateDeck();

        HashSet<Card> cardSet = new HashSet<>(dealer.deck);
        assertEquals(52, cardSet.size(), "Generated deck should have 52 unique cards");
    }
    
    
    //2 tests for DealHand
	@Test
	void dealHandTest1() {
		BaccaratDealer dealer = new BaccaratDealer();
		dealer.generateDeck();
		dealer.deck.remove(0);
		ArrayList<Card> hand = dealer.dealHand();

		assertEquals(2,hand.get(0).value, "Incorrect card number");
		assertEquals("Diamonds",hand.get(0).suite,"Incorrect suite");
		assertEquals(3,hand.get(1).value, "Incorrect card number");
		assertEquals("Diamonds",hand.get(1).suite,"Incorrect suite");
	}
	
    @Test
    void dealHandTest2() {
        BaccaratDealer dealer = new BaccaratDealer();
        dealer.generateDeck();

        ArrayList<Card> hand = dealer.dealHand();

        assertEquals(2, hand.size(), "Hand should have 2 cards");
    }
    
    
    //2 Tests for drawOne
    @Test
    void drawOneTest1() {
        BaccaratDealer dealer = new BaccaratDealer();
        dealer.generateDeck();
        int initialDeckSize = dealer.deckSize();

        Card drawnCard = dealer.drawOne();

        assertEquals(initialDeckSize - 1, dealer.deckSize(), "Deck size should decrease by 1 after drawing one card");
        assertEquals(initialDeckSize - 1, dealer.deck.size(), "Deck size and actual deck content size should match");
    }
    
    @Test
	void drawOneTest2() {
		BaccaratDealer dealer = new BaccaratDealer();
		dealer.generateDeck();
		Card card = dealer.drawOne();
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		Card card2 = dealer.drawOne();
		Card card3 = dealer.drawOne();

		assertEquals(1, card.value, "Incorrect card number");
		assertEquals("Diamonds", card.suite,"Incorrect suite");

		assertEquals(8, card2.value, "Incorrect card number");
		assertEquals("Diamonds", card2.suite,"Incorrect suite");

		assertEquals(9, card3.value, "Incorrect card number");
		assertEquals("Diamonds", card3.suite,"Incorrect suite");
	}
    
    //2 Tests for shuffleDeck
    @Test
    void shuffleDeck1() {
        BaccaratDealer dealer = new BaccaratDealer();
        dealer.generateDeck();

        dealer.shuffleDeck();
        int initialDeckSize = dealer.deckSize();

        assertEquals(initialDeckSize, dealer.deckSize(), "Incorrect deck size");
    }
    
	@Test
	void shuffleDeck2() {
		BaccaratDealer dealer = new BaccaratDealer();
		dealer.generateDeck();
		Card card = dealer.deck.get(0);

		assertEquals(1,card.value, "Incorrect card number");
		assertEquals("Diamonds",card.suite,"Incorrect suite");
		dealer.shuffleDeck();
	}
	
	//2 Tests for deckSize()
	
	@Test
	void deckSize1() {
		BaccaratDealer dealer = new BaccaratDealer();
		dealer.generateDeck();
		assertEquals(52, dealer.deckSize(),"Incorrect deck size");
		dealer.deck.remove(0);
		assertEquals(51, dealer.deckSize(),"Incorrect deck size");
		dealer.deck.remove(0);
		assertEquals(50, dealer.deckSize(),"Incorrect deck size");
		dealer.deck.remove(0);
		assertEquals(49, dealer.deckSize(),"Incorrect deck size");
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		dealer.deck.remove(0);
		assertEquals(44, dealer.deckSize(),"Incorrect deck size");
	}
	
	@Test
    void deckSize2() {
        BaccaratDealer dealer = new BaccaratDealer();
        int expectedDeckSize = 52; 

        dealer.generateDeck();

        assertEquals(expectedDeckSize, dealer.deckSize(), "Incorrect deck size");
    }
	
	//Tests for BaccaratGame
	//Test for evaualtWinngs -> This test does't work since we have UI elements in our fuction, the function works but unsure how to test with the elemetns. 
//	@Test
//    void evaualtWinningsTest1() {
//        BaccaratGame baccaratGame = new BaccaratGame();
//
//        // Test case 1: Bet on Banker and Banker wins
//        double betAmount = 50.0;
//        int playerTotal = 4; // Assuming the total points for the player is 4
//        int bankerTotal = 6; // Assuming the total points for the banker is 6
//        String betChoice = "Banker";
//        double expectedWinnings = betAmount; // Banker wins, so the expected winnings should be the bet amount
//
//        baccaratGame.evaluateWinnings(betChoice, "Banker", playerTotal, bankerTotal, betAmount);
//        assertEquals(expectedWinnings, baccaratGame.currentWinnings);
//
//        // Test case 2: Bet on Player and it's a Draw
//        betAmount = 100.0;
//        playerTotal = 6; // Assuming the total points for the player is 6
//        bankerTotal = 6; // Assuming the total points for the banker is 6
//        betChoice = "Player";
//        expectedWinnings = 0.0; // It's a draw, so the expected winnings should be 0
//
//        baccaratGame.evaluateWinnings(betChoice, "Draw", playerTotal, bankerTotal, betAmount);
//        assertEquals(expectedWinnings, baccaratGame.currentWinnings);
//    }
}
