
public class Card {

	String suite;
	int value;
	public Card(String theSuite, int theValue) {
		suite = theSuite;
		value = theValue;
	}
}

