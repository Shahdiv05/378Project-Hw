import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class SavingsMethodTest {
	public static MyMoney myMoneyTest1;
	public static MyMoney myMoneyTest2;
	
    @BeforeAll
    public static void testSetup() { 
    	myMoneyTest1 = new MyMoney("values.txt", 8, 1);
    	myMoneyTest2 = new MyMoney("values2.txt", 8, 2);
    }
    
	@Test	//Test 1
	public void futureValueLumpSumTest1() {
	    assertEquals(1629, Math.round(SavingsFormulas.futureValueLumpSum(1000, 0.05, 10)), "wrong output");
	}
	
	@Test 	//Test 2
	public void futureValueLumpSumTest2() {
	    assertEquals(2000, Math.round(SavingsFormulas.futureValueLumpSum(2000, 0.0, 20)), "wrong output");
	}
	
	@Test	//Test 3
	public void futureValueLumpSumTest3() {
		assertEquals(9495, Math.round(SavingsFormulas.futureValueLumpSum(9000, 0.055, 1)), "wrong output");
	}
	
	@Test	//Test 4
	public void futureValueLumpSumTest4() { 
		assertEquals(4840, Math.round(SavingsFormulas.futureValueLumpSum(4000, 0.1, 2)), "wrong output");
	}
	
	@Test	//Test 5
    void futureValueLS_VariableInterestTest1() { 
        assertEquals(14449, Math.round(SavingsFormulas.futureValueLS_VariableInterest(9000, myMoneyTest2.getInterestValues())), "wrong output");
    }
	
    @Test	//Test 6
    void futureValueLS_VariableInterestTest2() {
        assertEquals(8830 ,Math.round(SavingsFormulas.futureValueLS_VariableInterest(5500, myMoneyTest2.getInterestValues())), "wrong output");
    }
    
    @Test	//Test 7
    void compoundSavingsConstantTest1() { 
        assertEquals(31500, Math.round(SavingsFormulas.compoundSavingsConstant(15000, 0.1, 2)), "wrong output");
    }
    
    @Test	//Test 8
    void compoundSavingsConstantTest2() { 
        assertEquals(49080, Math.round(SavingsFormulas.compoundSavingsConstant(24000, .045, 2)), "wrong output");
    }
    
    @Test	//Test 9
    public void compoundSavingsConstantTest3() {
        assertEquals(12578, Math.round(SavingsFormulas.compoundSavingsConstant(1000, 0.05, 10)), "wrong output");
    }
    
    @Test	//Test 10
    void compoundSavingsVariableTest1() { // sees if formula is correct and output matches what we have
        assertEquals(106549, Math.round(SavingsFormulas.compoundSavingsVariable(myMoneyTest1.getCashValues(),.025)), "wrong output");
    }
    
    @Test	//Test 11
    void compoundSavingsVariableTest2() { // // sees if formula is correct and output matches what we have
        assertEquals(113475, Math.round(SavingsFormulas.compoundSavingsVariable(myMoneyTest1.getCashValues(),.045)), "wrong output");
    }
    
    //Total tests in savingsMehtodTest = 11
    
    //Total tests in both files 24
    
}
