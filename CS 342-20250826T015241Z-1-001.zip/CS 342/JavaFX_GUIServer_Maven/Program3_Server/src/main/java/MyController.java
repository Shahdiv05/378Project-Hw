//import java.io.IOException;
//import java.net.URL;
//import java.util.ResourceBundle;
//
//import javafx.application.Platform;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.fxml.Initializable;
//import javafx.scene.Parent;
//import javafx.scene.control.Button;
//import javafx.scene.control.ListView;
//import javafx.scene.control.TextField;
//import javafx.scene.layout.AnchorPane;
//import javafx.scene.text.Text;
//
//public class MyController {
//    Server serverConnection;
//
//    @FXML
//    private TextField Port;
//
//    @FXML
//    AnchorPane root;
//
//    @FXML
//    AnchorPane root2;
//
//    @FXML
//    ListView<String> InfoServer;
//
//    public void CreateController() throws IOException {
//        serverConnection = new Server(data -> {
//            Platform.runLater(()->{
//                System.out.println(data.toString());
//            });
//        }, Integer.parseInt(Port.getText()));
//
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Myfxml2.fxml"));
//        Parent root2 = loader.load();
//        root.getScene().setRoot(root2);
//    }
//}

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class MyController {
    Server serverConnection;

    @FXML
    private TextField Port;

    @FXML
    private AnchorPane root;

    @FXML
    private AnchorPane root2;

    @FXML
    private ListView<String> InfoServer;

    public void CreateController() throws IOException {
        serverConnection = new Server(data -> {
            Platform.runLater(() -> {
                System.out.println(data.toString());
            });
        }, Integer.parseInt(Port.getText()));

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Myfxml2.fxml"));
        Parent root2 = loader.load();
        root.getScene().setRoot(root2);
    }
}

