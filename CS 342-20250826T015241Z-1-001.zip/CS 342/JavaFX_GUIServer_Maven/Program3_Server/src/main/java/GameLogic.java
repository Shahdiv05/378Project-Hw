import java.util.ArrayList;
import java.util.Random;

public class GameLogic {
    ArrayList<String> Animals;
    ArrayList<String> Cities;
    ArrayList<String> Sports;
    ArrayList<String> usedWords;
    String currWord = "";
    String currCategory;
    String wordGuessWithDashes;
    Random rand;
    int categoriesWon = 0;
    int guessesRemaining = 6;
    boolean wordGuessed;

    public String getCurrWord() {
        return currWord;
    }
    public void PopulateWordLists() {
        Animals = new ArrayList<>();
        Cities = new ArrayList<>();
        Sports = new ArrayList<>();
        usedWords = new ArrayList<>();

        Animals.add("llama");
        Animals.add("koala");
        Animals.add("seal");
        Animals.add("tiger");
        Animals.add("whale");
        Animals.add("snail");
        Animals.add("python");

        Cities.add("seattle");
        Cities.add("seoul");
        Cities.add("delhi");
        Cities.add("london");
        Cities.add("berlin");
        Cities.add("moscow");
        Cities.add("beijing");

        Sports.add("cricket");
        Sports.add("tennis");
        Sports.add("football");
        Sports.add("rugby");
        Sports.add("hockey");
        Sports.add("boxing");
        Sports.add("swimming");

    }

    public String repeat(int num) {
        String result = "";
        for(int i = 0; i < num; i++) {
            result = result+"-";
        }
        return result;
    }

    public void pickWord() {
        rand = new Random();
        if (currCategory.equals("Animals")) {
            int randIndex = rand.nextInt(Animals.size()-1);
            currWord = Animals.get(randIndex);
            currCategory = "Animals";
            Animals.remove(currWord);
            usedWords.add(currWord);
            wordGuessWithDashes = repeat(currWord.length());

        } else if(currCategory.equals("Cities")) {
            int randIndex = rand.nextInt(Cities.size()-1);
            currWord = Cities.get(randIndex);
            currCategory = "Cities";
            Cities.remove(currWord);
            usedWords.add(currWord);
            wordGuessWithDashes = repeat(currWord.length());
        } else if (currCategory.equals("Sports")) {
            int randIndex = rand.nextInt(Sports.size()-1);
            currWord = Sports.get(randIndex);
            currCategory = "Sports";
            Sports.remove(currWord);
            usedWords.add(currWord);
            wordGuessWithDashes = repeat(currWord.length());
        }
        wordGuessed = false;
    }

    public boolean correctGuess(char letter, String wordInProgress) {
        boolean result = false;
        if (Character.isAlphabetic(letter)) {
            letter = Character.toLowerCase(letter);
            for (int i = 0; i < wordInProgress.length(); i++) {
                if (currWord.charAt(i) == letter && wordInProgress.charAt(i) != letter) {
                    wordInProgress = wordInProgress.substring(0, i) + letter + wordInProgress.substring(i+1);
                    result = true;
                }
            }

            wordGuessWithDashes = wordInProgress;

            if (wordInProgress.equals(currWord)) {
                wordGuessed = true;
                categoriesWon++;
                return true;
            }
        }
        
        if (!result) {
            if (guessesRemaining == 0) {
                wordGuessed = false;
                return false;
            }
            guessesRemaining -= 1;
        }

        return result;
    }

    public boolean isWinning() {
        return (categoriesWon == 3);
    }

    public boolean isLosing() {
        return (Animals.size() == 4 || Cities.size() == 4 || Sports.size() == 4);
    }
}

//import java.util.HashMap;
//import java.util.Map;
//import java.util.Random;
//import java.util.Scanner;
//
//class GameLogic {
//    private GameInfo gameInfo;
//
//    public GameLogic() {
//        this.gameInfo = new GameInfo();
//    }
//
//    public String startGame() {
//        return gameInfo.chooseCategory();
//    }
//
//    public String processGuess(String letter) {
//        return gameInfo.makeGuess(letter);
//    }
//
//    public static void main(String[] args) {
//        GameLogic gameLogic = new GameLogic();
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.println(gameLogic.startGame());
//
//        while (true) {
//            System.out.print("Enter a letter: ");
//            String guess = scanner.nextLine();
//            String result = gameLogic.processGuess(guess);
//            System.out.println(result);
//
//            if (result.contains("Congratulations") || result.contains("Game over")) {
//                System.out.print("Do you want to play again? (yes/no): ");
//                String playAgain = scanner.nextLine();
//                if (playAgain.equalsIgnoreCase("yes")) {
//                    System.out.println(gameLogic.startGame());
//                } else {
//                    System.out.println("Goodbye!");
//                    break;
//                }
//            }
//        }
//    }
//}