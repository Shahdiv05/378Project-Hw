import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class MyController3 {
    GameInfo gameInfo;
    static Client clientConnection;
    @FXML
    private Text WordToGuess;

    @FXML
    private TextField UserInput;

    public void updateWordToGuess(String word) {
        WordToGuess.setText(word);
    }

    public void getGameInfoAndClient(GameInfo game, Client client) {
        gameInfo = game;
        clientConnection = client;
    }


    public void ExitController(ActionEvent e) throws IOException {
        Platform.exit();
        System.exit(1);
    }

    public void SendController(ActionEvent e) throws IOException, InterruptedException {
//        WordToGuess.setText(clientConnection.gameInfo.getWordInProgress());
//        WordToGuess.setFont(Font.font(60));
        String word = UserInput.getText();
        if (word.length() > 1) {
            WordToGuess.setText("Input One Character");
            WordToGuess.setFont(Font.font(15));
        } else if (word.length() == 1) {
            WordToGuess.setFont(Font.font(60));
            gameInfo.setGuess(word.charAt(0));
            clientConnection.send(gameInfo);
            PauseTransition pause = new PauseTransition(Duration.seconds(0.5));

            pause.setOnFinished(actionEvent -> {
                WordToGuess.setText(clientConnection.gameInfo.getWordInProgress());
                updateWordToGuess(clientConnection.gameInfo.getWordInProgress());
                System.out.println(clientConnection.gameInfo.getWordInProgress());
            });

            pause.play();
//            if (clientConnection.gameInfo.isWon()) {
//                FXMLLoader loader = new FXMLLoader(getClass().getResource("/FXML/Myfxml4.fxml"));
//                Parent root4 = loader.load();
//                root3.getScene().setRoot(root4);
//            } else if () {
//
//            }
        }
    }
}
