import java.util.ArrayList;
import java.util.Collections;

public class BaccaratDealer {
	ArrayList<Card> deck = new ArrayList<Card>();
	
	public BaccaratDealer() {
        generateDeck();
        shuffleDeck();
    }
	
	public void generateDeck() {
	    deck.clear(); // Clear any existing deck
	    
	    String[] suits = {"Diamonds", "Spades", "Hearts", "Clubs"};

	    for (String suit : suits) {
	        for (int i = 1; i <= 13; i++) {
	            // Create cards for ranks from 1 to 13
	            Card card = new Card(suit, i);
	            deck.add(card);
	        }
	    }
	}
	
	public ArrayList<Card> dealHand(){
		ArrayList<Card> hand = new ArrayList<>();
		
		Card card1 = deck.get(0);
		Card card2 = deck.get(1);
		
		hand.add(card1);
		hand.add(card2);
		
		deck.remove(0);
		deck.remove(0);
		
		return hand;
	}
	
	public Card drawOne() {
		if (deckSize() == 0) {
            generateDeck();
            shuffleDeck();
        }
		
		Card card = deck.get(0);
		deck.remove(0);
		
		return card;
	}
	
	public void shuffleDeck() {
		Collections.shuffle(deck);
	}
	
	public int deckSize() {
		return deck.size();
	}
}
