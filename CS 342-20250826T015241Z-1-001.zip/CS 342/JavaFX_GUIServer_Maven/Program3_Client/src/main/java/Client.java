import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;



public class Client extends Thread{


    Socket socketClient;
    GameInfo gameInfo = new GameInfo();
    ObjectOutputStream out;
    ObjectInputStream in;

    int Port;
    private Consumer<Serializable> callback;

    Client(Consumer<Serializable> call, int port){
        this.Port = port;
        this.callback = call;
    }

    public void run() {

        try {
            socketClient= new Socket("127.0.0.1",Port);
            out = new ObjectOutputStream(socketClient.getOutputStream());
            in = new ObjectInputStream(socketClient.getInputStream());
            socketClient.setTcpNoDelay(true);
        }
        catch(Exception e) {}

        while(true) {

            try {
                gameInfo = (GameInfo) in.readObject();
                callback.accept(gameInfo);
            }
            catch(Exception e) {}
        }

    }

    public void send(GameInfo data) {

        try {
            out.flush();
            out.reset();
            out.writeObject(data);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}