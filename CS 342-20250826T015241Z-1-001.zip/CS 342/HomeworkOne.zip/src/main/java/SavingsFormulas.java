
/**************************
 *
 *  Homework 1: Maven and Java
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

public class SavingsFormulas {

	//This method takes a lump sum of money and figures out how much it 
	//will be worth in a certain number of years at a constant interest rate.
	public static double futureValueLumpSum(double cash, double interest, int years) {
		return cash * Math.pow(1 + interest, years);
	}
	
	//this is the helper function that helps make it recruivse 
	private static double helperFunction1(double cash, double values[], int val2) {
        if (0 >= val2) {
            return cash; 
        }
        return helperFunction1(cash, values, val2 - 1) * (1 + values[val2-1]); 
  
    }
	//This method takes a lump sum of money and figures out how much 
	//it will be worth in a certain number of years at a varying interest rate per year
    public static double futureValueLS_VariableInterest(double cash, double values[]) {
    	int val1 = values.length;
        return helperFunction1(cash, values, val1); 
    }
	
    
    //This method calculates the future value of saving the same amount of money each year 
    //for a certain number of years at a constant interest rate.
	public static double compoundSavingsConstant(double cash, double interest, int years) {
		return cash * ((Math.pow(1 + interest, years) - 1) / interest);
	}
	
	//this is the helper function that helps make it recurivse 
    private static double helperFunction2(double[] values, double interest, int val4) {
        if (1 >= val4) {
            return values[0]; // returns the first year
        }
        return helperFunction2(values, interest, val4 - 1) * (1 + interest) + values[val4-1]; 
    }
    //This method calculates the future value of investing a different amount of money at 
    //the end of each year for a certain number of years at a constant interest rate.
    public static double compoundSavingsVariable(double values[], double interest) {
    	int val3 = values.length;
        return helperFunction2(values, interest,val3);
    }
	
}

