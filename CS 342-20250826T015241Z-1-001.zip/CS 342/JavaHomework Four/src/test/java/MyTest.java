import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {
	private JavaFXTemplate homeWorkApp;
	
    @BeforeEach
    void setUp() {
    	homeWorkApp = new JavaFXTemplate();
    }

    @Test
    public void valueTest1() {
        assertTrue(homeWorkApp.isNumeric("25"));
    }

    @Test
    public void valueTest2() {
        assertFalse(homeWorkApp.isNumeric("abc"));
    }
    
    @Test
    public void valueTest3() {
        assertFalse(homeWorkApp.isNumeric("21D"));
    }
    
    @Test
    public void ageTest1() {
        assertTrue(homeWorkApp.isAgeValid("20"));
    }

    @Test
    public void ageTest2() {
        assertTrue(homeWorkApp.isAgeValid("18"));
    }
    
    @Test
    public void ageTest3() {
        assertFalse(homeWorkApp.isAgeValid("15"));
    }
    
    @Test
    public void ageTest4() {
    	assertFalse(homeWorkApp.isAgeValid("0"));
    }
    
    @Test
    public void ageTest5() {
        assertFalse(homeWorkApp.isAgeValid("-18"));
    }
    
    @Test
    public void ageTest6() {
        assertFalse(homeWorkApp.isAgeValid(""));
    }
    
    @Test
    public void ageTest7() {
    	assertFalse(homeWorkApp.isAgeValid("201"));
    }

}
