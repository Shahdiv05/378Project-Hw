import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.function.Consumer;

public class Server {
    int count = 1;
    ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
    TheServer server;
    static int Port;
    private Consumer<Serializable> callback;

    Server(Consumer<Serializable> call, int port) {
        this.Port = port;
        callback = call;
        server = new TheServer();
        server.start();
    }

    public class TheServer extends Thread {
        public void run() {
            try(ServerSocket mysocket = new ServerSocket(Port);) {
                System.out.println("Server is waiting for a client!");
                while(true) {
                    ClientThread c = new ClientThread(mysocket.accept(), count);
                    callback.accept("Client has connected to server: client #" + count);
                    clients.add(c);
                    c.start();
                    count++;
                }
            } catch(Exception e) {
                callback.accept("Server socket did not launch");
            }
        }
    }

    class ClientThread extends Thread{
        Socket connection;
        int count;
        ObjectInputStream in;
        ObjectOutputStream out;
        GameInfo gameInfo;
        GameLogic gameLogic;

        ClientThread(Socket s, int count) {
            this.connection = s;
            this.count = count;
            gameInfo = new GameInfo();
            gameLogic = new GameLogic();
        }

        public void run() {
            try {
                in = new ObjectInputStream(connection.getInputStream());
                out = new ObjectOutputStream(connection.getOutputStream());
                connection.setTcpNoDelay(true);
            }
            catch(Exception e) {
                System.out.println("Streams not open");
            }

            while(true) {
                try {
                    gameInfo = (GameInfo) in.readObject();
                    gameLogic.currCategory = gameInfo.getCategory();
                    gameLogic.PopulateWordLists();
                    if (gameLogic.currWord.equals("") || gameInfo.getWordInProgress().equals(gameLogic.currWord) || gameInfo.getGuessesRemaining() == 0) {
                        gameLogic.pickWord();
                    }

                    GameInfo curr = gameInfo;
                    String word = gameLogic.currWord;
                    char guess = curr.getGuess();
                    boolean correctGuess;

                    if (curr.getWordLength() == 0) {
                        curr.setWordLength(word.length());
                    }

                    if (curr.getWordInProgress().equals("")) {
                        curr.setWordInProgress(gameLogic.wordGuessWithDashes);
                    }

                    if (guess != ' '){
                        correctGuess = gameLogic.correctGuess(guess, curr.getWordInProgress());
                        curr.setWordGuessed(gameLogic.wordGuessed);
                        curr.setWon(gameLogic.isWinning());
                        curr.setLost(gameLogic.isLosing());
                        curr.setWordInProgress(gameLogic.wordGuessWithDashes);
                        curr.setGuessesRemaining(gameLogic.guessesRemaining);
                        if (correctGuess && curr.isWordGuessed() && curr.isWon()) {
                            curr.setMessage("Congratulations!! You won!");
                            callback.accept("client: " + count + " guessed the letter: " + guess + "\n"
                                               +"client: " + count + " Guessed the word correctly and won the game");
                        } else if (correctGuess && curr.isWordGuessed()) {
                            curr.setMessage("Hurray!! You guessed the word");
                            callback.accept("client: " + count + " guessed the letter: " + guess + "\n"
                                            + "client: " + count + " Guessed the word correctly.");
                        } else if (correctGuess) {
                            curr.setMessage("Nice work! Guess another letter");
                            callback.accept("client: " + count + " guessed the letter: " + guess + "\n"
                                    + "client: " + count + " Guessed the correct letter.");
                        } else if (!correctGuess && !curr.isWordGuessed() && curr.isLost()) {
                            curr.setMessage("Sorry!! You lost the game :(");
                            callback.accept("client: " + count + " guessed the letter: " + guess + "\n"
                                    + "client: " + count + " Guessed the word incorrectly and lost the game");
                        } else if (!curr.isWordGuessed() && curr.getGuessesRemaining() == 0){
                            curr.setMessage("You could not guess the word. Try another word");
                            callback.accept("client: " + count + " guessed the letter: " + guess + "\n"
                                    + "client: " + count + " Guessed the word incorrectly.");
                        } else if (!correctGuess) {
                            curr.setMessage("Incorrect letter. Pick another letter");
                            callback.accept("client: " + count + " guessed the letter: " + guess + "\n"
                                    + "client: " + count + " Guessed the incorrect letter.");
                        }
                    }
                    out.reset();
                    out.flush();
                    out.writeObject(curr);
                }
                catch(Exception e) {
                    callback.accept("OOOOPPs...Something wrong with the socket from client: " + count + "....closing down!");
                    clients.remove(this);
                    break;
                }
            }
        }
    }
}


//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.io.Serializable;
//import java.net.ServerSocket;
//import java.net.Socket;
//import java.util.ArrayList;
//import java.util.function.Consumer;
//
//public class Server {
//
//    private int port;
//    private ServerSocket serverSocket;
//    private ArrayList<ClientHandler> clients = new ArrayList<>();
//    private Consumer<Serializable> callback;
//
//    public Server(Consumer<Serializable> callback, int port) {
//        this.callback = callback;
//        this.port = port;
//    }
//
//    public void start() {
//        try {
//            serverSocket = new ServerSocket(port);
//            callback.accept("Server is running on port " + port);
//
//            while (true) {
//                Socket clientSocket = serverSocket.accept();
//                callback.accept("New client connected.");
//
//                ClientHandler clientHandler = new ClientHandler(clientSocket);
//                clients.add(clientHandler);
//                clientHandler.start();
//            }
//        } catch (IOException e) {
//            callback.accept("Error starting the server.");
//        }
//    }
//
//    private class ClientHandler extends Thread {
//        private Socket clientSocket;
//        private ObjectOutputStream out;
//        private ObjectInputStream in;
//
//        public ClientHandler(Socket clientSocket) {
//            this.clientSocket = clientSocket;
//        }
//
//        @Override
//        public void run() {
//            try {
//                out = new ObjectOutputStream(clientSocket.getOutputStream());
//                in = new ObjectInputStream(clientSocket.getInputStream());
//                clientSocket.setTcpNoDelay(true);
//
//                while (true) {
//                    // Assuming your GameInfo class implements Serializable
//                    GameInfo receivedData = (GameInfo) in.readObject();
//                    callback.accept("Received data from client: " + receivedData);
//
//                    // Do whatever processing or response needed here
//                    // For example, broadcast the received data to all clients
//                    broadcast(receivedData);
//                }
//            } catch (IOException | ClassNotFoundException e) {
//                callback.accept("Client disconnected.");
//                clients.remove(this);
//            }
//        }
//
//        public void send(GameInfo data) {
//            try {
//                out.reset();
//                out.writeObject(data);
//            } catch (IOException e) {
//                callback.accept("Error sending data to the client.");
//            }
//        }
//    }
//
//    private void broadcast(GameInfo data) {
//        for (ClientHandler client : clients) {
//            client.send(data);
//        }
//    }
//
//    public static void main(String[] args) {
//        int port = 5555; // Change this to your desired port
//        Server server = new Server(System.out::println, port);
//        server.start();
//    }
//}