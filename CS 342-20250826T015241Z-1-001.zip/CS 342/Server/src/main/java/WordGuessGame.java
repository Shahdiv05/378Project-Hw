import java.util.List;

public class WordGuessGame {
    private List<Category> categories;
    private Category currentCategory;
    private Player currentPlayer;
    static final int MAX_GUESSES = 6;

    public WordGuessGame(List<Category> categories) {
        this.currentPlayer = new Player("DefaultPlayerName");
        startGame();
    }

    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    public Category getCurrentCategory() {
        return currentCategory;
    }

    public void startGame() {
        switchCategory();
    }

    public void processGuess(char letter) {
        currentPlayer.makeGuess(letter);
        // Logic to process the guess, update game state, and communicate with the server
    }

    public void switchCategory() {
        // Logic to switch to the next category
        currentCategory = /* get the next category from the list */
        currentCategory.setCurrentWord(currentCategory.getNextWord());
        currentPlayer.resetGuesses();
    }

    public boolean isGameOver() {
        // Logic to check if the game is over
        return false; // return true if the game is over
    }

    public boolean isGameWon() {
        // Logic to check if the game is won
        return false; // return true if the game is won
    }

    public void playAgain() {
        // Logic to reset the game for a new round
        startGame();
    }
}
