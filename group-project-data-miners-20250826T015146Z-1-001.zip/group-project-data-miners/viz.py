import matplotlib.pyplot as plt

def create_ev_yearly_from_total(df):
    df2 = df[['County', 'EV_Count']].copy()
    for i in range(len(df2)):
        total = df2.iloc[i]['EV_Count']
        df2.at[i, 'EV_Count_2020'] = total / 5
        df2.at[i, 'EV_Count_2021'] = total / 5
        df2.at[i, 'EV_Count_2022'] = total / 5
        df2.at[i, 'EV_Count_2023'] = total / 5
        df2.at[i, 'EV_Count_2024'] = total / 5
    df2 = df2.drop('EV_Count', axis=1)
    return df2

def plot_top5_income_and_ev_growth(df):
    df_sorted = df.sort_values(by='EV_Count', ascending=False)
    top5 = df_sorted.head(5)
    ev_yearly = create_ev_yearly_from_total(df)
    years = ['2020', '2021', '2022', '2023', '2024']
    fig, ax1 = plt.subplots(figsize=(8, 4.5))

    for i in range(len(top5)):
        county = top5.iloc[i]['County']
        income_vals = []
        for year in years:
            col1 = year + '_Median_Income'
            if col1 in top5.columns:
                income_vals.append(top5.iloc[i][col1])
            else:
                col2 = 'Median_Income_' + year
                income_vals.append(top5.iloc[i][col2])
        ax1.plot(years, income_vals, marker='o', label=county + ' Income')

    ax1.set_xlabel('Year')
    ax1.set_ylabel('Median Income')
    ax2 = ax1.twinx()

    for i in range(len(top5)):
        county = top5.iloc[i]['County']
        ev_vals = []
        for year in years:
            ev_vals.append(ev_yearly[ev_yearly['County'] == county].iloc[0]['EV_Count_' + year])
        ax2.plot(years, ev_vals, linestyle='--', marker='x', label=county + ' EVs')

    ax2.set_ylabel('EV Count (Estimated)')
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='center left', bbox_to_anchor=(1.20, 0.5), fontsize=9)

    plt.title('Top 5 Counties: Median Income and EV Growth (2020-2024)')
    plt.tight_layout()
    plt.show()
