import java.util.ArrayList;

public class BaccaratGameLogic {
	int total;
	int bankerHand;
	int playerHand;
	int numCards;
	
	public String whoWon(ArrayList<Card> hand1, ArrayList<Card> hand2) {
		bankerHand = handTotal(hand1);
		playerHand = handTotal(hand2);
		
		if(playerHand == 8 || playerHand == 9 || bankerHand == 8 || bankerHand == 9) {
			if(playerHand > bankerHand) {
				return "Player";
			}
			else if(bankerHand > playerHand) {
				return "Banker";
			}
			else {
				return "Draw";
			}	
		}
		
		if(playerHand < 6 || bankerHand < 6) {
			return "Draw";
		}
		
		if(playerHand < bankerHand) {
			return "Banker";
		}
		
		else if(bankerHand < playerHand) {
			return "Player";
		}
		else {
			return "Draw";
		}
	}
	
	public int handTotal(ArrayList<Card> hand) {
		total = 0;
		for(Card card : hand) {
			if(card.value < 10) {
				total += card.value;
			}
			else {
				total += 0;
			}
		}
		
		if(total < 10) {
			return total;
		}
		else {
			return total - 10;
		}
	}
	
	public boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard) {
		numCards = handTotal(hand);
		
		if((numCards >= 0) && (numCards <= 2)) {
			return true;
		}
		else if(numCards == 3) {

			return playerCard.value != 8;
		}
		else if(numCards == 4) {

			return playerCard.value >= 2 && playerCard.value <= 7;
		}
		else if(numCards == 5) {

			return playerCard.value >= 4 && playerCard.value <= 7;
		}
		else if(numCards == 6) {

			return playerCard.value == 6 || playerCard.value == 7;
		}
		else {
			return false;
		}
	}
	
	public boolean evaluatePlayerDraw(ArrayList<Card> hand) {
		numCards = handTotal(hand);
		if (numCards <= 5) {
			return true;
		}
		return false;
	}
}
