import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.ArrayList;

public class BaccaratGame extends Application {
    ArrayList<Card> playerHand = new ArrayList<>();
    ArrayList<Card> bankerHand = new ArrayList<>();
    BaccaratDealer theDealer = new BaccaratDealer();
    BaccaratGameLogic gameLogic = new BaccaratGameLogic();

    Label playerLabel = new Label("Player's Cards:");
    Label bankerLabel = new Label("Banker's Cards:");
    Label resultLabel = new Label();
    Label winnerMessage = new Label();
    Label playerScore = new Label();
    Label bankerScore = new Label();
    Button playButton = new Button("Play Game");
    TextField betAmountText = new TextField();
    ComboBox<String> betChoiceBox = new ComboBox<>();
    Label currentWinningsLabel = new Label("Current Winnings: $0.00");
    MenuBar menuBar = new MenuBar();
    Menu optionsMenu = new Menu("Options");
    MenuItem exitMenuItem = new MenuItem("Exit");
    MenuItem freshStartMenuItem = new MenuItem("Fresh Start");

    @Override
    public void start(Stage primaryStage) {
    	welcomeScreen(primaryStage);
    }

    private void welcomeScreen(Stage primaryStage) {
        BorderPane welcomeRoot = new BorderPane();
        welcomeRoot.setStyle("-fx-background-color: #008001;");

        VBox welcomeCenter = new VBox(20);
        welcomeCenter.setPadding(new Insets(20));

        Label welcomeLabel = new Label("Welcome to Baccarat Game");
        welcomeLabel.setStyle("-fx-font-size: 24;");

        Button playButton = new Button("Play");
        playButton.setOnAction(e -> setupGame(primaryStage));

        welcomeCenter.getChildren().addAll(welcomeLabel, playButton);
        welcomeRoot.setCenter(welcomeCenter);

        Scene welcomeScene = new Scene(welcomeRoot, 650, 650);
        primaryStage.setScene(welcomeScene);
        primaryStage.setTitle("Welcome to Baccarat Game");
        primaryStage.show();
    }


    private void setupGame(Stage primaryStage) {
    	BorderPane root = new BorderPane();
        VBox mainArea = new VBox(10);
        VBox cardDisplay = new VBox(10);
        HBox playerCardsBox = new HBox(5);
        HBox bankerCardsBox = new HBox(5);
        HBox controlArea = new HBox(10);
        VBox resultArea = new VBox(10);


        betChoiceBox.getItems().addAll("Player", "Banker", "Draw");
        betChoiceBox.setValue("Player");

        playerCardsBox.getChildren().add(playerLabel);
        bankerCardsBox.getChildren().add(bankerLabel);
        cardDisplay.getChildren().addAll(playerCardsBox, bankerCardsBox);

        controlArea.getChildren().addAll(new Label("Bet Amount:"), betAmountText, betChoiceBox, playButton);
        resultArea.getChildren().addAll(playerScore, resultLabel, winnerMessage, currentWinningsLabel);
        
        VBox.setMargin(resultArea, new Insets(20, 0, 0, 0));
        
        mainArea.getChildren().addAll(cardDisplay, resultArea);

        root.setTop(menuBar);
        root.setCenter(mainArea);
        root.setBottom(controlArea);

        exitMenuItem.setOnAction(e -> primaryStage.close());
        freshStartMenuItem.setOnAction(e -> freshStart());

        optionsMenu.getItems().addAll(exitMenuItem, freshStartMenuItem);
        menuBar.getMenus().add(optionsMenu);

        playButton.setOnAction(e -> playGame());

        Scene scene = new Scene(root, 600, 600);
        setStyles(root, playerLabel, bankerLabel, resultLabel, currentWinningsLabel, betAmountText, betChoiceBox, playButton, winnerMessage, playerScore);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Baccarat Game");
        primaryStage.show();
    }

    private void playGame() {
        double betAmount;
        String betChoice;
        try {
            betAmount = Double.parseDouble(betAmountText.getText());
            betChoice = betChoiceBox.getValue();
        } catch (NumberFormatException | NullPointerException e) {
            return;
        }

        if (betAmount <= 0 || betChoice.isEmpty()) {
            return;
        }

        playerHand = theDealer.dealHand();
        bankerHand = theDealer.dealHand();

        playerLabel.setText("Player's Cards: " + getCardString(playerHand));
        bankerLabel.setText("Banker's Cards: " + getCardString(bankerHand));

        int playerTotal = gameLogic.handTotal(playerHand);
        int bankerTotal = gameLogic.handTotal(bankerHand);
        
     	// Evaluate whether the banker should draw another card
        if (gameLogic.evaluateBankerDraw(bankerHand, playerHand.get(0))) {
        	Card newBankerCard = theDealer.drawOne();
            bankerHand.add(newBankerCard);
            bankerTotal = gameLogic.handTotal(bankerHand);
            
            bankerLabel.setText(bankerLabel.getText() + " " + newBankerCard.suite + " " + newBankerCard.value + ",");
        }

        // Evaluate whether the player should draw another card
        if (gameLogic.evaluatePlayerDraw(playerHand)) {
        	Card newPlayerCard = theDealer.drawOne();
            playerHand.add(newPlayerCard);
            playerTotal = gameLogic.handTotal(playerHand);

            playerLabel.setText(playerLabel.getText() + " " + newPlayerCard.suite + " " + newPlayerCard.value + ",");
        }

        String winner = gameLogic.whoWon(playerHand, bankerHand);

        if (winner.equals("Banker")) {
        	playerScore.setText("Player Total: " + playerTotal + "  Banker Total: " + bankerTotal);
            resultLabel.setText("Banker wins");
            if (betChoice == "Banker") {
            	winnerMessage.setText("Congrats, you bet Banker! You win!");
            }
            else if (betChoice == "Player") {
            	winnerMessage.setText("Sorry, you bet Player! You lost your bet!");
            }
            else {
            	winnerMessage.setText("Sorry, you bet Draw! You lost your bet!");
            }
            evaluateWinnings(betChoice, "Banker", playerTotal, bankerTotal, betAmount);
        } else if (winner.equals("Player")) {
        	playerScore.setText("Player Total: " + playerTotal + "  Banker Total: " + bankerTotal);
            resultLabel.setText("Player wins");
            if (betChoice == "Player") {
            	winnerMessage.setText("Congrats, you bet Player! You win!");
            }
            else if (betChoice == "Banker") {
            	winnerMessage.setText("Sorry, you bet Banker! You lost your bet!");
            }
            else {
            	winnerMessage.setText("Sorry, you bet Draw! You lost your bet!");
            }
            evaluateWinnings(betChoice, "Player", playerTotal, bankerTotal, betAmount);
        } else {
        	playerScore.setText("Player Total: " + playerTotal + "  Banker Total: " + bankerTotal);
            resultLabel.setText("It's a Draw");
            if (betChoice == "Draw") {
            	winnerMessage.setText("Congrats, you bet Draw! You win!");
            }
            else if (betChoice == "Player") {
            	winnerMessage.setText("Sorry, you bet Player! You lost your bet!");
            }
            else {
            	winnerMessage.setText("Sorry, you bet Banker! You lost your bet!");
            }
            evaluateWinnings(betChoice, "Draw", playerTotal, bankerTotal, betAmount);
        }

    }


    public double currentWinnings = 0.0;

    public void evaluateWinnings(String betChoice, String winner, int playerTotal, int bankerTotal, double betAmount) {
        double winnings = 0.0;

        if (betChoice.equals(winner)) {
            if (winner.equals("Draw")) {
                winnings = betAmount * 8;
            } 
            else {
                winnings = betAmount;
            }
        }

        currentWinnings += winnings;
        currentWinningsLabel.setText("Current Winnings: $" + currentWinnings);
    }

    private String getCardString(ArrayList<Card> hand) {
        StringBuilder cardString = new StringBuilder();
        for (Card card : hand) {
            cardString.append(card.suite).append(" ").append(card.value).append(", ");
        }
        return cardString.toString();
    }

    private void freshStart() {
        playerHand.clear();
        bankerHand.clear();
        currentWinnings = 0.0;
        currentWinningsLabel.setText("Current Winnings: $0.00");
        resultLabel.setText("");
    }

    private void setStyles(Pane root, Control... controls) {
        for (Control control : controls) {
            control.setStyle("-fx-text-fill: black; -fx-font-size: 18px;");
        }

        root.setStyle("-fx-background-color: red;");
    }

    public static void main(String[] args) {
        launch(args);
    }
}