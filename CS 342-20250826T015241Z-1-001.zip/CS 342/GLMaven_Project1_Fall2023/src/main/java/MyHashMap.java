/**************************
 *
 *  Project 1: Data Structure Library - MyHashMap
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import java.util.ArrayList;
import java.util.Iterator;

//This class we will create out own map. Unfortunately I was unable to finish it, some of the method are present but they have errors therefore are commented out.

public class MyHashMap<T> implements Iterable<T> {
	
    private ArrayList<GenericQueue<Entry<T>>> map;		
    
    public MyHashMap(String key, T value) {	//constructor
        map = new ArrayList<>(10);
        for (int i = 0; i <= 9; i++) {
            map.add(new GenericQueue<Entry<T>>(null));
        }
        put(key, value);
    }
    
    public void put(String key, T value) {	//this method will take a key value pair and Create a hash code and hash value using the key passed into the method
        int hashValue = key.hashCode() & 9; 
        GenericQueue<Entry<T>> queue = map.get(hashValue);
        Entry<T> newEntry = new Entry<>(key, value);
        queue.enqueue(newEntry);
    }

    @Override
    public Iterator<T> iterator() {
        return null;
    }
    
    private static class Entry<T> {			//Used this for the put funciton 
        private String key;
        private T value;
        
        public Entry(String key, T value) {
            this.key = key;
            this.value = value;
        }
    }
//    
//    public boolean contains(String key) {		//this method will check to see if the given key exists in the HashMap and return true if yes and false if no.
//        int hashValue = key.hashCode() & 9;
//        GenericQueue<GenericList.Node<Pair<String, T>>> queue = map.get(hashValue);
//
//         //Check if the key exists in the queue
//        for (GenericList.Node<Pair<String, T>> node : queue) {
//            if (node.getData().getKey().equals(key)) {
//                return true;
//            }
//        }
//
//        return false; // Key not found
//    }
//
//    public T get(String key) {	//this method will return the value at the given key or return null if it does not exist.
//        int hashValue = key.hashCode() & 9;
//        GenericQueue<GenericList.Node<Pair<String, T>>> queue = map.get(hashValue);
//
//        // Find and return the value associated with the key
//        for (GenericList.Node<Pair<String, T>> node : queue) {
//           if (node.getData().getKey().equals(key)) {
//                return node.getData().getValue();
//            }
//       }
//
//        return null; // Key not found
//   }
    	public int size() {		//returns the number of key-value mappings in the map.
    		int count = 0;
    		int size = 0;
    		for (GenericQueue<MyHashMap.Entry<T>> queue : map) {
    			size += queue.getLength();
    		}
    		return size;
    	}

    	public boolean isEmpty() {	//returns true if this map contains no key-value mappings.
    		return size() == 0;
    	}
    
//   public T replace(String key, T value) {	//replaces the entry for the specified key only if it is currently mapped to some value.
//       int hashValue = key.hashCode() & 9;
//       GenericQueue<GenericList.Node<Pair<String, T>>> queue = map.get(hashValue);
//
//        // Find and replace the value associated with the key
//        for (GenericList.Node<Pair<String, T>> node : queue) {
//            if (node.getData().getKey().equals(key)) {
//                T oldValue = node.getData().getValue();
//               node.getData().setValue(value);
//                return oldValue; // Return the old value
//            }
//        }
//
//        return null; // Key not found, no replacement done
//   }

    
    
}
