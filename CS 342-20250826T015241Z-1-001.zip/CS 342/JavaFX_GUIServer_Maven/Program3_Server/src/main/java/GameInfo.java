import java.io.Serializable;

public class GameInfo implements Serializable {
    static final long serialVersionUID = 1357924680;

    private int wordLength = 0;
    private int guessesRemaining = 6;
    private boolean won = false;
    private boolean lost = false;
    private boolean wordGuessed = false;
    private String category;
    private String wordInProgress =  "";
    private String message;
    private char guess = ' ';


    public int getWordLength() {
        return wordLength;
    }

    public int getGuessesRemaining() {
        return guessesRemaining;
    }

    public boolean isWon() {
        return won;
    }

    public boolean isLost() {
        return lost;
    }

    public boolean isWordGuessed() {
        return wordGuessed;
    }

    public String getCategory() {
        return category;
    }

    public String getWordInProgress() {
        return wordInProgress;
    }

    public String getMessage() {
        return message;
    }

    public char getGuess() {
        return guess;
    }

    public void setWordLength(int length) {
        wordLength = length;
    }

    public void setGuessesRemaining(int guesses) {
        guessesRemaining = guesses;
    }

    public void setWon(boolean winning) {
        won = winning;
    }

    public void setLost (boolean losing) {
        lost = losing;
    }

    public void setWordGuessed (boolean word) {
        wordGuessed = word;
    }

    public void setCategory (String cat) {
        category = cat;
    }

    public void setWordInProgress (String str) {
        this.wordInProgress = str;
    }

    public void setMessage (String msg) {
        message = msg;
    }

    public void setGuess (char letter) {
        guess = letter;
    }
}

//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.Random;
//import java.util.Scanner;
//
//public class GameInfo {
//    private Map<String, List<String>> categories;
//    private String currentCategory;
//    private String currentWord;
//    private int wordIndex;
//    private int guessesLeft;
//
//    public GameInfo() {
//        this.categories = new HashMap<>();
//        this.categories.put("Nations", createNations());
//        this.categories.put("Colors", createColors());
//        this.categories.put("Sports", createSports());
//        this.currentCategory = "";
//        this.currentWord = "";
//        this.wordIndex = 0;
//        this.guessesLeft = 6;
//    }
//
//    private List<String> createNations() {
//        List<String> nations = new ArrayList<>();
//        nations.add("United States");
//        nations.add("India");
//        nations.add("Canada");
//        nations.add("England");
//        nations.add("Spain");
//        nations.add("Brazil");
//        nations.add("China");
//        return nations;
//    }
//
//    private List<String> createColors() {
//        List<String> colors = new ArrayList<>();
//        colors.add("Blue");
//        colors.add("Green");
//        colors.add("Red");
//        colors.add("Pink");
//        colors.add("White");
//        colors.add("Black");
//        colors.add("Purple");
//        return colors;
//    }
//
//    private List<String> createSports() {
//        List<String> sports = new ArrayList<>();
//        sports.add("Basketball");
//        sports.add("Baseball");
//        sports.add("Football");
//        sports.add("Tennis");
//        sports.add("Cricket");
//        sports.add("Golf");
//        sports.add("Hockey");
//        return sports;
//    }
//
//    public String chooseCategory() {
//        Random random = new Random();
//        List<String> categoryList = new ArrayList<>(categories.keySet());
//        this.currentCategory = categoryList.get(random.nextInt(categoryList.size()));
//        this.wordIndex = 0;
//        this.currentWord = categories.get(currentCategory).get(wordIndex);
//        this.guessesLeft = 6;
//        return "Category: " + currentCategory + "\nWord Length: " + currentWord.length();
//    }
//
//    public String makeGuess(String letter) {
//        if (currentWord.contains(letter)) {
//            StringBuilder revealedWord = new StringBuilder();
//            for (char ch : currentWord.toCharArray()) {
//                if (ch == letter.charAt(0) || ch == ' ' || ch == '-') {
//                    revealedWord.append(ch);
//                } else {
//                    revealedWord.append('_');
//                }
//            }
//
//            if (revealedWord.toString().equals(currentWord)) {
//                wordIndex++;
//                if (wordIndex < 3) {
//                    currentWord = words.get(currentCategory)[wordIndex];
//                    return "Correct! Word Guessed: " + currentWord + "\nChoose a new word from the same category.";
//                } else {
//                    return "Congratulations! You've guessed a word in each category. You won!";
//                }
//            } else {
//                return "Correct! " + revealedWord + "\nGuesses left: " + guessesLeft;
//            }
//        } else {
//            guessesLeft--;
//            if (guessesLeft > 0) {
//                return "Incorrect! Guesses left: " + guessesLeft;
//            } else {
//                return "Game over. No more guesses left. Choose a new word from any category.";
//            }
//        }
//    }
//}