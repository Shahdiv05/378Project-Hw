import java.util.ArrayList; 
import java.util.Iterator; 
import java.util.LinkedList; 
import java.util.Collections;

public class GenericPractice<M extends Number & Comparable<M>> {
    //private ArrayList<M> list; ->This was for the arraylist
	private LinkedList<M> list;
    private M initVal;

    public GenericPractice(M value){
        this.initVal = value;
        list = new LinkedList<>();
        //list = new ArrayList<>(); ->This was for the arrayList
        list.add(value);
    }
    
    
    //this method will add val to the ArrayList
    public void storeValue(M val){
        list.add(val);
    }
    
    
    //this method will replace the value at “index with “val”.
    public void changeValue(M val,int index){
        list.set(index,val);
    }
    
    
    //print out the values of the ArrayList using an iterator. Print “empty list” if the list is empty.
    public void printArray(){
        if(list.isEmpty())
        {
            System.out.println("Empty list");
            return;
        }
        Iterator<M> check = list.iterator();
        while (check.hasNext())
        {
            System.out.print(check.next() + " ");
        }
        System.out.println();
    }
    
    
    //sort the values in the ArrayList and print using a for-each loop.
    public void sortPrintArray(){
        if(list.isEmpty())
        {
            System.out.println("Empty list");
            return;
        }
        Collections.sort(list);
        for (M n : list) {
            System.out.print(n + " ");
        }
        System.out.println();
    }
    
    
    //sort ArrayList values in reverse order and print the values using a forEach method. 
    public void sortReversePrintArray(){
        if(list.isEmpty()){
        	System.out.println("Empty list");
        	return;
        }
        Collections.sort(list,Collections.reverseOrder());
        for (M n :list) {
            System.out.print(n + " ");
        }
        System.out.println();
    }
    
    
    //clears the values in the ArrayList
    public void clearList(){
        list.clear();
    }
	
    
	public static void main(String[] args) {
		//System.out.println("check");
		GenericPractice<Integer> testMain1 = new GenericPractice<>(55);
		System.out.println("First test: ");
		testMain1.storeValue(100);
		testMain1.storeValue(35);
		testMain1.storeValue(95);
		testMain1.storeValue(25);
        System.out.print("Original: ");
        testMain1.printArray();
        System.out.print("Sorted: ");
        testMain1.sortPrintArray();
        System.out.print("Reverse Sorted: ");
        testMain1.sortReversePrintArray();
        
        testMain1.clearList();
        System.out.print("After clear: ");
        testMain1.printArray();
        
        GenericPractice<Integer> testMain2 = new GenericPractice<>(7);
        System.out.println("Second test: ");
        testMain2.storeValue(5);
        testMain2.storeValue(8);
        testMain2.storeValue(0);
        testMain2.storeValue(1);
        testMain2.storeValue(2);
        testMain2.storeValue(6);
        testMain2.storeValue(10);
        testMain2.storeValue(9);
        System.out.print("Original Array: ");
        testMain2.printArray();
        System.out.print("Sorted Array: ");
        testMain2.sortPrintArray();
        System.out.print("Reverse Sorted Array: ");
        testMain2.sortReversePrintArray();
        
        testMain2.clearList();
        System.out.print("After clear: ");
        testMain2.printArray();
	}
}

