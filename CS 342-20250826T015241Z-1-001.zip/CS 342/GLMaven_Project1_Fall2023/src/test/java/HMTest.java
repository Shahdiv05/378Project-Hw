/**************************
 *
 *  Project 1: Data Structure Library - GQ Testing
    Course: CS 342, Fall 2023
    System: Eclipse - maven
    Professor Mark Hallenbeck 
    Student Author: Divya Shah
 *
 * ************************/

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

public class HMTest {

	
	private MyHashMap<Integer> hashMap;

    @BeforeEach
    void setUp() {
        hashMap = new MyHashMap<>("key1", 42);
    }
        
    @Test
    void sizeTest1() {
    	//assertEquals(1, hashMap.size()); //Answer should be 1 since there is only 1 entry but size function returns 11
        assertEquals(11, hashMap.size());	
    }
    
//    @Test	//This tests checks with more then 1 enterer but due to my code no being complete right this doesn't work.
//    void morethen1enteir() {
//        hashMap.put("key2", 23);
//        hashMap.put("key3", 45);
//        assertEquals(3, hashMap.size());
//    }
}
